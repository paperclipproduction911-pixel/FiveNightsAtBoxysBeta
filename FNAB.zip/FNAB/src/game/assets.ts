import { previewPathPrefix } from "@/lib/preview-path-prefix";

/** Root-relative URL that still works under path-based previews. */
export function asset(path: string): string {
  if (typeof window === "undefined") return path;
  const prefix = previewPathPrefix(window.location.hostname, window.location.pathname) ?? "";
  return `${prefix}${path}`;
}

export const ART = [
  "office",
  "door",
  "hall_l",
  "hall_r",
  "fan0",
  "fan1",
  "fan2",
  "fan3",
  "pizza",
  "cam_1a",
  "cam_1b",
  "cam_1c",
  "cam_1c_open",
  "cam_2a",
  "cam_2b",
  "cam_3a",
  "cam_3b",
  "cam_4a",
  "cam_4b",
  "spr_boxy",
  "spr_pepper",
  "spr_crumb",
  "spr_mozz",
  "door_boxy",
  "door_pepper",
  "door_crumb",
  "door_mozz",
  "mozz_peek",
  "boxy_win",
  "scare_boxy_0",
  "scare_boxy_1",
  "scare_boxy_2",
  "scare_boxy_3",
  "scare_pepper_0",
  "scare_pepper_1",
  "scare_pepper_2",
  "scare_pepper_3",
  "scare_crumb_0",
  "scare_crumb_1",
  "scare_crumb_2",
  "scare_crumb_3",
  "scare_mozz_0",
  "scare_mozz_1",
  "scare_mozz_2",
  "scare_mozz_3",
] as const;

export type ArtName = (typeof ART)[number];
export type Img = CanvasImageSource & { width: number; height: number };

export function loadArt(): Promise<Record<string, Img>> {
  return Promise.all(
    ART.map(
      (name) =>
        new Promise<[string, Img]>((resolve) => {
          const img = new Image();
          img.onload = () => resolve([name, img]);
          img.onerror = () => {
            const c = document.createElement("canvas");
            c.width = 4;
            c.height = 4;
            resolve([name, c]);
          };
          img.src = asset(`/boxys/${name}.png`);
        }),
    ),
  ).then((pairs) => Object.fromEntries(pairs));
}
