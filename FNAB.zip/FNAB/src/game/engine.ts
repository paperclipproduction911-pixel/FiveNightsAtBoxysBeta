import { Sfx } from "./audio";
import { loadArt, type Img } from "./assets";
import {
  CAM_LIST,
  DRAIN,
  HOUR_SECONDS,
  LOC_CAM,
  NIGHTS,
  hourLabel,
  readSave,
  writeSave,
  type AiSet,
  type CamId,
  type CharId,
  type Hud,
  type Loc,
  type Mover,
  type Screen,
} from "./types";

const VW = 640;
const VH = 360;
const S = 2;

type Rect = { x: number; y: number; w: number; h: number };

const DOOR_L: Rect = { x: 6, y: 46, w: 92, h: 200 };
const DOOR_R: Rect = { x: 542, y: 46, w: 92, h: 200 };
const BTN = {
  Ldoor: { x: 8, y: 308, w: 86, h: 46 },
  Llight: { x: 100, y: 308, w: 86, h: 46 },
  cam: { x: 248, y: 308, w: 144, h: 46 },
  tablet: { x: 268, y: 248, w: 104, h: 52 },
  Rlight: { x: 454, y: 308, w: 86, h: 46 },
  Rdoor: { x: 546, y: 308, w: 86, h: 46 },
};
const FEED: Rect = { x: 12, y: 16, w: 400, h: 250 };
const MAP_X = 424;
const MAP_Y = 16;
const CELL_W = 66;
const CELL_H = 56;
const CELL_GAP = 6;
const YOU: Rect = { x: 424, y: 206, w: 204, h: 42 };

const PEPPER: Loc[] = ["stage", "dining", "westHall", "westCorner", "leftDoor"];
const CRUMB: Loc[] = ["stage", "dining", "kitchen", "eastHall", "eastCorner", "rightDoor"];
const BOXY_L: Loc[] = ["stage", "dining", "parts", "westHall", "westCorner", "leftDoor"];
const BOXY_R: Loc[] = ["stage", "dining", "parts", "eastHall", "eastCorner", "rightDoor"];

/** feetX, feetY, height inside the 400×250 camera plate. */
const SLOTS: Record<CamId, Partial<Record<CharId, [number, number, number]>>> = {
  "1A": { pepper: [78, 228, 158], boxy: [200, 226, 176], crumb: [328, 228, 156] },
  "1B": { pepper: [90, 210, 130], boxy: [200, 200, 145], crumb: [310, 214, 128] },
  "1C": { mozz: [200, 214, 168] },
  "2A": { pepper: [188, 214, 145], boxy: [230, 208, 155], mozz: [170, 216, 150] },
  "2B": { pepper: [200, 230, 185], boxy: [210, 226, 195], mozz: [190, 230, 190] },
  "3A": { crumb: [176, 214, 145], boxy: [230, 208, 155] },
  "3B": { crumb: [200, 230, 185], boxy: [214, 226, 195] },
  "4A": { crumb: [210, 200, 150] },
  "4B": { boxy: [250, 200, 155], pepper: [90, 205, 120], crumb: [330, 205, 120] },
};

const MELODY = [196, 233, 196, 174, 155, 174, 196, 146, 174, 196, 233, 311, 277, 233, 196, 155];

const TIPS: Record<number, string> = {
  1: "Pepper uses the west hall. Hold the light. Shut the door. Cameras drink power.",
  2: "Boxy freezes while his camera is up. Check Curtain Cove or Mozz runs.",
  3: "Pots mean Crumb is in the kitchen. The east door is next.",
  4: "They are faster. Both doors at once will kill the power.",
  5: "Mozz sprints the west hall. One closed door stops him and Pepper.",
  6: "All four are awake. Conserve every percent until 6 AM.",
};

function hit(x: number, y: number, r: Rect) {
  return x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h;
}

function attackDelay(ai: number) {
  return 4.8 - (Math.max(0, Math.min(20, ai)) / 20) * 3.3;
}

function mapRect(col: number, row: number): Rect {
  return {
    x: MAP_X + col * (CELL_W + CELL_GAP),
    y: MAP_Y + row * (CELL_H + CELL_GAP),
    w: CELL_W,
    h: CELL_H,
  };
}

export class BoxysGame {
  private ctx: CanvasRenderingContext2D;
  private sfx = new Sfx();
  private imgs: Record<string, Img> = {};
  private running = false;
  private raf = 0;
  private last = 0;
  private onHud: (h: Hud) => void;
  private hudKey = "";

  screen: Screen = "loading";
  night = 1;
  isCustom = false;
  ai: AiSet = { ...NIGHTS[1] };
  customAi: AiSet = { boxy: 1, pepper: 1, crumb: 1, mozz: 1 };
  hour = 0;
  hourAcc = 0;
  power = 100;
  drain = 1;
  powerOut = false;
  powerOutTimer = 0;
  musicTimer = 0;
  musicStep = 0;
  leftDoor = false;
  rightDoor = false;
  leftDoorAnim = 0;
  rightDoorAnim = 0;
  leftLight = false;
  rightLight = false;
  private lightKey = { L: false, R: false };
  private lightPtr = { L: false, R: false };
  camUp = false;
  camId: CamId = "1A";
  camStatic = 0;
  loc: Record<Mover, Loc> = { boxy: "stage", pepper: "stage", crumb: "stage" };
  attack: Record<Mover, number> = { boxy: 0, pepper: 0, crumb: 0 };
  boxySide: "L" | "R" = "R";
  mozzPhase: 0 | 1 | 2 | 3 = 0;
  mozzHeat = 0;
  mozzRun = -1;
  moveTimer = 4;
  potTimer = 5;
  heartTimer = 1;
  paused = false;
  time = 0;
  shake = 0;
  menuIndex = 0;
  customIndex = 0;
  quitJoke = false;
  scareWho: CharId | null = null;
  scareT = 0;
  save = readSave();
  private removeListeners: (() => void) | null = null;

  constructor(canvas: HTMLCanvasElement, onHud: (h: Hud) => void) {
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("canvas unsupported");
    this.ctx = ctx;
    this.onHud = onHud;
    this.ctx.imageSmoothingEnabled = false;
  }

  async start() {
    this.imgs = await loadArt();
    try {
      await document.fonts.load('20px "Press Start 2P"');
    } catch {
      /* bitmap fallback is the browser monospace */
    }
    this.bind();
    this.screen = "menu";
    this.running = true;
    this.last = performance.now();
    this.emit(true);
    this.raf = requestAnimationFrame(this.frame);
    this.publishDebug();
  }

  stop() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.removeListeners?.();
    this.removeListeners = null;
  }

  action(id: string) {
    this.sfx.unlock();
    this.sfx.click();
    this.quitJoke = false;
    if (id === "new") this.startNight(1, false);
    else if (id === "continue") this.startNight(this.save.unlocked, false);
    else if (id === "custom") {
      this.screen = "custom";
      this.customIndex = 0;
    } else if (id === "extras") this.screen = "extras";
    else if (id === "quit") this.quitJoke = true;
    else if (id === "menu") {
      this.screen = "menu";
      this.paused = false;
      this.sfx.setFan(false);
      this.sfx.setCamHiss(false);
    } else if (id === "begin") this.beginPlay();
    else if (id === "retry") this.startNight(this.night, this.isCustom);
    else if (id === "next") {
      if (this.isCustom || this.night >= 6) this.screen = "menu";
      else this.startNight(this.night + 1, false);
    } else if (id === "resume") this.paused = false;
    else if (id === "night") {
      /* handled via startNight from UI */
    }
    this.emit(true);
  }

  startNight(night: number, custom: boolean) {
    this.night = night;
    this.isCustom = custom;
    this.ai = custom ? { ...this.customAi } : { ...NIGHTS[night] };
    const sum = this.ai.boxy + this.ai.pepper + this.ai.crumb + this.ai.mozz;
    this.drain = custom ? 0.9 + sum / 90 : (DRAIN[night] ?? 1);
    this.resetRuntime();
    this.screen = "intro";
    this.sfx.unlock();
    this.emit(true);
  }

  bumpAi(who: CharId, delta: number) {
    this.customAi[who] = Math.max(0, Math.min(20, this.customAi[who] + delta));
    this.sfx.click();
    this.emit(true);
  }

  loadPreset(night: number) {
    this.customAi = { ...NIGHTS[night] };
    this.sfx.click();
    this.emit(true);
  }

  toggleMute() {
    this.sfx.setMuted(!this.sfx.muted);
    this.sfx.unlock();
    this.emit(true);
  }

  toggleDoor(side: "L" | "R") {
    if (this.screen !== "play" || this.paused || this.powerOut) return;
    if (side === "L") this.leftDoor = !this.leftDoor;
    else this.rightDoor = !this.rightDoor;
    this.shake = 0.08;
    this.sfx.unlock();
    this.sfx.door();
    this.emit();
  }

  setLight(side: "L" | "R", on: boolean, src: "key" | "ui" = "ui") {
    if (src === "key") this.lightKey[side] = on;
    else this.lightPtr[side] = on;
    const next = (this.lightKey[side] || this.lightPtr[side]) && !this.powerOut && this.screen === "play" && !this.paused;
    if (side === "L") {
      if (next && !this.leftLight) this.sfx.light();
      this.leftLight = next;
    } else {
      if (next && !this.rightLight) this.sfx.light();
      this.rightLight = next;
    }
    this.emit();
  }

  toggleCam() {
    if (this.screen !== "play" || this.paused || this.powerOut) return;
    this.camUp = !this.camUp;
    this.camStatic = 0.22;
    this.sfx.unlock();
    this.sfx.cam();
    this.sfx.setCamHiss(this.camUp);
    this.emit();
  }

  closeCam() {
    if (!this.camUp) return;
    this.camUp = false;
    this.sfx.setCamHiss(false);
    this.sfx.cam();
    this.emit();
  }

  selectCam(id: CamId) {
    if (this.screen !== "play" || !this.camUp) return;
    if (this.camId !== id) {
      this.camId = id;
      this.camStatic = 0.16;
      this.sfx.cam();
    }
    this.emit();
  }

  onKey(code: string, down: boolean, repeat: boolean) {
    if (down && repeat) return;
    if (down) this.sfx.unlock();
    if (code === "KeyM" && down) {
      this.toggleMute();
      return;
    }
    if (this.screen === "menu" && down) {
      if (code === "ArrowDown") this.menuIndex = (this.menuIndex + 1) % 5;
      else if (code === "ArrowUp") this.menuIndex = (this.menuIndex + 4) % 5;
      else if (code === "Enter" || code === "Space") {
        const ids = ["new", "continue", "custom", "extras", "quit"];
        const id = ids[this.menuIndex];
        if (id === "continue" && this.save.unlocked <= 1 && !this.save.beat) return;
        this.action(id);
        return;
      }
      this.emit();
      return;
    }
    if (this.screen === "custom" && down) {
      const rows: CharId[] = ["boxy", "pepper", "crumb", "mozz"];
      if (code === "ArrowDown") this.customIndex = Math.min(4, this.customIndex + 1);
      else if (code === "ArrowUp") this.customIndex = Math.max(0, this.customIndex - 1);
      else if (code === "ArrowLeft" && this.customIndex < 4) this.bumpAi(rows[this.customIndex], -1);
      else if (code === "ArrowRight" && this.customIndex < 4) this.bumpAi(rows[this.customIndex], 1);
      else if ((code === "Enter" || code === "Space") && this.customIndex === 4) this.startNight(7, true);
      else if (code === "Escape") this.action("menu");
      this.emit();
      return;
    }
    if ((this.screen === "intro" || this.screen === "extras") && down) {
      if (code === "Enter" || code === "Space") {
        if (this.screen === "intro") this.beginPlay();
      } else if (code === "Escape") this.action("menu");
      return;
    }
    if ((this.screen === "over" || this.screen === "win" || this.screen === "finale") && down) {
      if (code === "Enter" || code === "Space") this.action(this.screen === "over" ? "retry" : "next");
      else if (code === "Escape") this.action("menu");
      return;
    }
    if (this.screen === "scare") return;
    if (this.screen !== "play") return;

    if (code === "Escape" && down) {
      if (this.camUp) this.closeCam();
      else this.paused = !this.paused;
      this.emit();
      return;
    }
    if (this.paused) {
      if (down && (code === "Enter" || code === "Space")) this.action("resume");
      return;
    }
    if (code === "KeyA" && down) this.toggleDoor("L");
    else if (code === "KeyD" && down) this.toggleDoor("R");
    else if (code === "KeyQ") this.setLight("L", down, "key");
    else if (code === "KeyE") this.setLight("R", down, "key");
    else if ((code === "Space" || code === "KeyS") && down) this.toggleCam();
    else if (down && this.camUp && /^Digit[1-9]$/.test(code)) {
      const idx = Number(code.slice(5)) - 1;
      const cam = CAM_LIST[idx];
      if (cam) this.selectCam(cam.id);
    }
  }

  private beginPlay() {
    this.screen = "play";
    this.paused = false;
    this.sfx.setFan(true);
    this.sfx.setCamHiss(false);
    this.emit(true);
  }

  private resetRuntime() {
    this.hour = 0;
    this.hourAcc = 0;
    this.power = 100;
    this.powerOut = false;
    this.powerOutTimer = 0;
    this.musicTimer = 0.2;
    this.musicStep = 0;
    this.leftDoor = false;
    this.rightDoor = false;
    this.leftDoorAnim = 0;
    this.rightDoorAnim = 0;
    this.leftLight = false;
    this.rightLight = false;
    this.lightKey = { L: false, R: false };
    this.lightPtr = { L: false, R: false };
    this.camUp = false;
    this.camId = "1A";
    this.camStatic = 0;
    this.loc = { boxy: "stage", pepper: "stage", crumb: "stage" };
    this.attack = { boxy: 0, pepper: 0, crumb: 0 };
    this.boxySide = "R";
    this.mozzPhase = 0;
    this.mozzHeat = 0;
    this.mozzRun = -1;
    this.moveTimer = 5;
    this.potTimer = 4;
    this.heartTimer = 1.2;
    this.paused = false;
    this.time = 0;
    this.shake = 0;
    this.scareWho = null;
    this.scareT = 0;
  }

  private bind() {
    const canvas = this.ctx.canvas;
    const down = (e: PointerEvent) => {
      if (this.screen !== "play" || this.paused) return;
      const p = this.pos(e);
      if (!p || this.powerOut) return;
      this.sfx.unlock();
      if (this.camUp) {
        for (const cam of CAM_LIST) {
          if (hit(p.x, p.y, mapRect(cam.col, cam.row))) {
            this.selectCam(cam.id);
            return;
          }
        }
        if (hit(p.x, p.y, YOU)) this.closeCam();
        return;
      }
      if (hit(p.x, p.y, BTN.Ldoor)) this.toggleDoor("L");
      else if (hit(p.x, p.y, BTN.Llight)) this.setLight("L", true, "ui");
      else if (hit(p.x, p.y, BTN.Rdoor)) this.toggleDoor("R");
      else if (hit(p.x, p.y, BTN.Rlight)) this.setLight("R", true, "ui");
      else if (hit(p.x, p.y, BTN.cam) || hit(p.x, p.y, BTN.tablet)) this.toggleCam();
    };
    const up = () => {
      if (this.lightPtr.L) this.setLight("L", false, "ui");
      if (this.lightPtr.R) this.setLight("R", false, "ui");
    };
    canvas.addEventListener("pointerdown", down);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    const vis = () => {
      if (document.hidden && this.screen === "play" && !this.paused) {
        this.paused = true;
        this.leftLight = false;
        this.rightLight = false;
        this.lightKey = { L: false, R: false };
        this.lightPtr = { L: false, R: false };
        this.emit(true);
      }
    };
    document.addEventListener("visibilitychange", vis);
    this.removeListeners = () => {
      canvas.removeEventListener("pointerdown", down);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      document.removeEventListener("visibilitychange", vis);
    };
  }

  private pos(e: PointerEvent) {
    const r = this.ctx.canvas.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return null;
    return {
      x: ((e.clientX - r.left) / r.width) * VW,
      y: ((e.clientY - r.top) / r.height) * VH,
    };
  }

  private frame = (now: number) => {
    if (!this.running) return;
    const dt = Math.min(0.05, Math.max(0, (now - this.last) / 1000));
    this.last = now;
    this.update(dt);
    this.render();
    this.raf = requestAnimationFrame(this.frame);
  };

  private update(dt: number) {
    this.time += dt;
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt);
    if (this.screen === "scare") {
      this.scareT += dt;
      if (this.scareT > 1.15) {
        this.screen = "over";
        this.emit(true);
      }
      return;
    }
    if (this.screen !== "play" || this.paused) return;

    this.hourAcc += dt;
    if (this.hourAcc >= HOUR_SECONDS) {
      this.hourAcc -= HOUR_SECONDS;
      this.hour += 1;
      if (this.hour >= 6) {
        this.winNight();
        return;
      }
      this.sfx.hour();
      this.emit();
    }

    const usage = this.usage();
    if (!this.powerOut) {
      this.power -= usage * 0.26 * this.drain * dt;
      if (this.power <= 0) {
        this.power = 0;
        this.powerOut = true;
        this.leftDoor = false;
        this.rightDoor = false;
        this.leftLight = false;
        this.rightLight = false;
        this.camUp = false;
        this.sfx.setFan(false);
        this.sfx.setCamHiss(false);
        this.powerOutTimer = 8 + Math.random() * 9;
        this.musicTimer = 0.05;
        this.emit();
      }
    } else {
      this.powerOutTimer -= dt;
      this.musicTimer -= dt;
      if (this.musicTimer <= 0) {
        this.sfx.note(MELODY[this.musicStep % MELODY.length]);
        this.musicStep += 1;
        this.musicTimer = 0.46;
      }
      if (this.powerOutTimer <= 0) {
        this.jumpscare("boxy");
        return;
      }
    }

    const animSpeed = 5.2;
    this.leftDoorAnim += ((this.leftDoor ? 1 : 0) - this.leftDoorAnim) * Math.min(1, dt * animSpeed);
    this.rightDoorAnim += ((this.rightDoor ? 1 : 0) - this.rightDoorAnim) * Math.min(1, dt * animSpeed);
    if (this.camStatic > 0) this.camStatic = Math.max(0, this.camStatic - dt);

    if (this.powerOut) {
      this.emit();
      return;
    }

    if (this.power < 16) {
      this.heartTimer -= dt;
      if (this.heartTimer <= 0) {
        this.sfx.heartbeat();
        this.heartTimer = 1.15;
      }
    }

    this.moveTimer -= dt;
    if (this.moveTimer <= 0) {
      this.moveTimer = 3.25 + Math.random() * 0.7;
      this.tryMove("pepper");
      this.tryMove("crumb");
      this.tryMove("boxy");
    }

    for (const who of ["pepper", "crumb", "boxy"] as const) {
      const door = this.atDoor(who);
      if (!door) {
        this.attack[who] = 0;
        continue;
      }
      const closed = door === "L" ? this.leftDoor : this.rightDoor;
      if (closed) {
        this.attack[who] = 0;
        continue;
      }
      this.attack[who] += dt;
      if (this.attack[who] > attackDelay(this.ai[who])) {
        this.jumpscare(who);
        return;
      }
    }

    this.updateMozz(dt);

    if (this.loc.crumb === "kitchen") {
      this.potTimer -= dt;
      if (this.potTimer <= 0) {
        this.sfx.pot();
        this.potTimer = 2.4 + Math.random() * 3.2;
      }
    }

    this.emit();
  }

  private usage() {
    return (
      1 +
      (this.leftDoor ? 1 : 0) +
      (this.rightDoor ? 1 : 0) +
      (this.leftLight ? 1 : 0) +
      (this.rightLight ? 1 : 0) +
      (this.camUp ? 1 : 0)
    );
  }

  private atDoor(who: Mover): "L" | "R" | null {
    if (this.loc[who] === "leftDoor") return "L";
    if (this.loc[who] === "rightDoor") return "R";
    return null;
  }

  private pathFor(who: Mover): Loc[] {
    if (who === "pepper") return PEPPER;
    if (who === "crumb") return CRUMB;
    return this.boxySide === "L" ? BOXY_L : BOXY_R;
  }

  private boxyWatched() {
    if (!this.camUp) return false;
    const cam = LOC_CAM[this.loc.boxy];
    return cam !== null && cam === this.camId;
  }

  private tryMove(who: Mover) {
    const ai = this.ai[who];
    if (ai <= 0) return;
    if (who === "boxy" && this.boxyWatched()) return;
    let chance = ai / 20;
    if (who === "boxy" && this.camUp) chance = Math.min(1, chance * 1.3);
    if (Math.random() > chance) return;
    const door = this.atDoor(who);
    if (door) {
      const closed = door === "L" ? this.leftDoor : this.rightDoor;
      if (closed) {
        const path = this.pathFor(who);
        const idx = path.indexOf(this.loc[who]);
        if (idx > 0) this.loc[who] = path[Math.max(0, idx - 2)];
        this.attack[who] = 0;
        this.sfx.thud(false);
      }
      return;
    }
    if (who === "boxy" && this.loc.boxy === "parts") {
      this.boxySide = Math.random() < 0.5 ? "L" : "R";
    }
    const path = this.pathFor(who);
    const idx = path.indexOf(this.loc[who]);
    if (idx < 0 || idx >= path.length - 1) return;
    const next = path[idx + 1];
    this.loc[who] = next;
    const close = next === "leftDoor" || next === "rightDoor" || next.endsWith("Corner");
    if (close || next.endsWith("Hall")) this.sfx.thud(close);
    if (next === "kitchen") this.sfx.pot();
  }

  private updateMozz(dt: number) {
    const ai = this.ai.mozz;
    if (ai <= 0) return;
    if (this.mozzPhase < 3) {
      const watching = this.camUp && this.camId === "1C";
      if (watching) this.mozzHeat = Math.max(0, this.mozzHeat - 14 * dt);
      else this.mozzHeat += (0.45 + ai * 0.3) * dt * (this.camUp ? 1.22 : 1);
      if (this.mozzHeat >= 100) {
        this.mozzPhase = 3;
        this.mozzRun = 3.3;
        this.sfx.mozzRun();
      } else if (this.mozzHeat > 68) this.mozzPhase = 2;
      else if (this.mozzHeat > 34) this.mozzPhase = 1;
      else this.mozzPhase = 0;
      return;
    }
    if (this.mozzRun >= 0) {
      this.mozzRun -= dt;
      if (this.mozzRun <= 0) {
        if (this.leftDoor) {
          this.sfx.bang();
          this.shake = 0.14;
          this.mozzPhase = 0;
          this.mozzHeat = 0;
          this.mozzRun = -1;
        } else {
          this.jumpscare("mozz");
        }
      }
    }
  }

  private jumpscare(who: CharId) {
    if (this.screen !== "play") return;
    this.screen = "scare";
    this.scareWho = who;
    this.scareT = 0;
    this.paused = false;
    this.leftLight = false;
    this.rightLight = false;
    this.sfx.setFan(false);
    this.sfx.setCamHiss(false);
    this.sfx.jumpscare(who);
    this.emit(true);
  }

  private winNight() {
    const finale = !this.isCustom && this.night >= 6;
    this.screen = finale ? "finale" : "win";
    this.sfx.setFan(false);
    this.sfx.setCamHiss(false);
    this.sfx.win();
    if (!this.isCustom) {
      const unlocked = this.night >= 6 ? 6 : Math.max(this.save.unlocked, this.night + 1);
      this.save = {
        ...this.save,
        unlocked,
        beat: this.save.beat || this.night >= 6,
      };
      writeSave(this.save);
    } else {
      this.save = { ...this.save, customWins: this.save.customWins + 1 };
      writeSave(this.save);
    }
    this.emit(true);
  }

  private emit(force = false) {
    const p = Math.ceil(this.power);
    const key = [
      this.screen,
      this.night,
      this.hour,
      p,
      this.usage(),
      this.camUp ? 1 : 0,
      this.camId,
      this.leftDoor ? 1 : 0,
      this.rightDoor ? 1 : 0,
      this.leftLight ? 1 : 0,
      this.rightLight ? 1 : 0,
      this.powerOut ? 1 : 0,
      this.paused ? 1 : 0,
      this.menuIndex,
      this.customIndex,
      this.quitJoke ? 1 : 0,
      this.customAi.boxy,
      this.customAi.pepper,
      this.customAi.crumb,
      this.customAi.mozz,
      this.save.unlocked,
      this.save.beat ? 1 : 0,
      this.scareWho,
      this.sfx.muted ? 1 : 0,
    ].join("|");
    if (!force && key === this.hudKey) return;
    this.hudKey = key;
    this.onHud(this.hud());
    this.publishDebug();
  }

  private hud(): Hud {
    const cam = CAM_LIST.find((c) => c.id === this.camId);
    return {
      screen: this.screen,
      night: this.night,
      custom: this.isCustom,
      hourLabel: hourLabel(this.hour),
      power: Math.max(0, Math.ceil(this.power)),
      usage: this.usage(),
      camUp: this.camUp,
      camId: this.camId,
      camName: cam?.name ?? "",
      leftDoor: this.leftDoor,
      rightDoor: this.rightDoor,
      leftLight: this.leftLight,
      rightLight: this.rightLight,
      powerOut: this.powerOut,
      paused: this.paused,
      menuIndex: this.menuIndex,
      customIndex: this.customIndex,
      ai: { ...this.customAi },
      unlocked: this.save.unlocked,
      beat: this.save.beat,
      customWins: this.save.customWins,
      quitJoke: this.quitJoke,
      scareWho: this.scareWho,
      muted: this.sfx.muted,
    };
  }

  private publishDebug() {
    const self = this;
    (window as unknown as { __BOXYS?: () => unknown }).__BOXYS = () => ({
      screen: self.screen,
      night: self.night,
      hour: self.hour,
      power: Math.round(self.power),
      usage: self.usage(),
      loc: { ...self.loc },
      leftDoor: self.leftDoor,
      rightDoor: self.rightDoor,
      camUp: self.camUp,
      camId: self.camId,
      mozzPhase: self.mozzPhase,
      mozzHeat: Math.round(self.mozzHeat),
      ai: { ...self.ai },
      paused: self.paused,
    });
  }

  private blit(img: Img | undefined, x: number, y: number, w: number, h: number) {
    if (!img) return;
    this.ctx.imageSmoothingEnabled = false;
    this.ctx.drawImage(img, x * S, y * S, w * S, h * S);
  }

  private text(
    str: string,
    x: number,
    y: number,
    size: number,
    color: string,
    align: CanvasTextAlign = "left",
  ) {
    this.ctx.font = `${size}px "Press Start 2P", monospace`;
    this.ctx.fillStyle = color;
    this.ctx.textAlign = align;
    this.ctx.textBaseline = "top";
    this.ctx.fillText(str, x, y);
    this.ctx.textAlign = "left";
  }

  private render() {
    const ctx = this.ctx;
    ctx.imageSmoothingEnabled = false;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    if (this.shake > 0) {
      ctx.translate((Math.random() - 0.5) * 10, (Math.random() - 0.5) * 6);
    }
    ctx.fillStyle = "#05060a";
    ctx.fillRect(-20, -20, 1280 + 40, 720 + 40);

    if (this.screen === "scare" && this.scareWho) {
      this.renderScare();
      return;
    }
    if (this.screen !== "play") {
      this.renderIdle();
      return;
    }
    if (this.camUp && !this.powerOut) this.renderCam();
    else this.renderOffice();

    if (this.power < 20 && !this.powerOut) {
      const a = 0.12 + Math.sin(this.time * 6) * 0.07;
      ctx.fillStyle = `rgba(120, 0, 0, ${a})`;
      ctx.fillRect(0, 0, 1280, 720);
    }
    // vignette
    const g = ctx.createRadialGradient(640, 360, 200, 640, 360, 760);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, "rgba(0,0,0,0.45)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 1280, 720);
  }

  private renderIdle() {
    const ctx = this.ctx;
    ctx.fillStyle = "#07060b";
    ctx.fillRect(0, 0, 1280, 720);
    // slow checker strip
    for (let i = 0; i < 32; i++) {
      ctx.fillStyle = i % 2 === 0 ? "#8e1c22" : "#e6e0d4";
      const x = ((i * 40 - (this.time * 18) % 40) | 0) - 40;
      ctx.fillRect(x, 680, 40, 18);
      ctx.fillRect(x, 22, 40, 12);
    }
  }

  private renderOffice() {
    this.blit(this.imgs.office, 0, 0, 640, 360);
    const fanFrame = this.powerOut ? 0 : Math.floor(this.time * (this.powerOut ? 0 : 16)) % 4;
    this.blit(this.imgs[`fan${fanFrame}`], 292, 158, 56, 56);
    // ceiling flicker
    if (!this.powerOut && Math.sin(this.time * 9) > 0.97) {
      this.ctx.fillStyle = "rgba(255,255,240,0.08)";
      this.ctx.fillRect(360, 8, 360, 80);
    }
    this.drawDoorway("L");
    this.drawDoorway("R");
    this.drawPad(BTN.Ldoor, "DOOR", this.leftDoor, "#e01818");
    this.drawPad(BTN.Llight, "LIGHT", this.leftLight, "#e2c84a");
    this.drawPad(BTN.cam, "CAMS", this.camUp, "#3ecf6e");
    this.drawPad(BTN.Rlight, "LIGHT", this.rightLight, "#e2c84a");
    this.drawPad(BTN.Rdoor, "DOOR", this.rightDoor, "#e01818");

    this.text(this.powerOut ? "POWER OUT" : `POWER ${Math.ceil(this.power)}%`, 24, 24, 16, this.power < 20 ? "#ff4040" : "#f4f0e6");
    this.drawUsage(24, 48);
    this.text(hourLabel(this.hour), 1280 - 24, 22, 18, "#f4f0e6", "right");
    this.text(this.isCustom ? "CUSTOM" : `NIGHT ${this.night}`, 1280 - 24, 48, 14, "#d01212", "right");

    if (this.powerOut) {
      this.ctx.fillStyle = "rgba(0,0,0,0.82)";
      this.ctx.fillRect(0, 0, 1280, 720);
      this.text("POWER OUT", 640, 80, 28, "#d01212", "center");
      if (Math.sin(this.time * 14) > 0.75) {
        this.ctx.fillStyle = "#f4f4f8";
        this.ctx.fillRect(560, 300, 36, 48);
        this.ctx.fillRect(680, 300, 36, 48);
        this.ctx.fillStyle = "#10080c";
        this.ctx.fillRect(572, 318, 12, 16);
        this.ctx.fillRect(692, 318, 12, 16);
      }
    }
  }

  private drawUsage(x: number, y: number) {
    const u = this.usage();
    this.text("USAGE", x, y, 12, "#9a947f");
    for (let i = 0; i < 6; i++) {
      this.ctx.fillStyle = i < u ? "#3dce6a" : "#1c2420";
      this.ctx.fillRect(x + 86 + i * 18, y, 14, 16);
    }
  }

  private drawPad(r: Rect, label: string, on: boolean, hot: string) {
    const x = r.x * S;
    const y = r.y * S;
    const w = r.w * S;
    const h = r.h * S;
    this.ctx.fillStyle = "#07080d";
    this.ctx.fillRect(x, y, w, h);
    this.ctx.fillStyle = on ? hot : "#23262f";
    this.ctx.fillRect(x + 4, y + 4, w - 8, h - 8);
    this.ctx.strokeStyle = on ? "#fff6" : "#3a3e4a";
    this.ctx.strokeRect(x + 4.5, y + 4.5, w - 9, h - 9);
    this.text(label, x + w / 2, y + h / 2 - 8, 13, on ? "#140c08" : "#efe6d2", "center");
  }

  private drawDoorway(side: "L" | "R") {
    const r = side === "L" ? DOOR_L : DOOR_R;
    const anim = side === "L" ? this.leftDoorAnim : this.rightDoorAnim;
    const light = side === "L" ? this.leftLight : this.rightLight;
    const ctx = this.ctx;
    ctx.save();
    ctx.beginPath();
    ctx.rect(r.x * S, r.y * S, r.w * S, r.h * S);
    ctx.clip();
    if (light && !this.powerOut) {
      this.blit(side === "L" ? this.imgs.hall_l : this.imgs.hall_r, r.x, r.y, r.w, r.h);
      const figures = this.figuresAt(side);
      figures.forEach((who, i) => {
        const img = this.imgs[`spr_${who}`];
        if (!img) return;
        const h = 168 - i * 8;
        const aspect = img.width / img.height;
        const w = h * aspect;
        const fx = r.x + r.w / 2 + (i === 0 ? 0 : 10);
        const fy = r.y + r.h - 2;
        const bob = Math.sin(this.time * 3 + i) * 1.2;
        this.blit(img, fx - w / 2, fy - h + bob, w, h);
      });
    }
    const slide = (1 - anim) * r.h;
    this.blit(this.imgs.door, r.x, r.y - slide, r.w, r.h);
    ctx.restore();
    // frame
    ctx.strokeStyle = "#0a090c";
    ctx.lineWidth = 8;
    ctx.strokeRect(r.x * S + 2, r.y * S + 2, r.w * S - 4, r.h * S - 4);
  }

  private figuresAt(side: "L" | "R"): CharId[] {
    const list: CharId[] = [];
    if (side === "L") {
      if (this.loc.pepper === "leftDoor") list.push("pepper");
      if (this.loc.boxy === "leftDoor") list.push("boxy");
      if (this.mozzPhase === 3 && this.mozzRun >= 0 && this.mozzRun < 1.55) list.push("mozz");
    } else {
      if (this.loc.crumb === "rightDoor") list.push("crumb");
      if (this.loc.boxy === "rightDoor") list.push("boxy");
    }
    return list;
  }

  private renderCam() {
    const ctx = this.ctx;
    ctx.fillStyle = "#08090d";
    ctx.fillRect(0, 0, 1280, 720);
    // bezel
    ctx.fillStyle = "#12141a";
    ctx.fillRect(8, 8, 808, 560);
    const plate =
      this.camId === "1C" && this.mozzPhase === 3 ? this.imgs.cam_1c_open : this.imgs[`cam_${this.camId.toLowerCase()}`];
    this.blit(plate, FEED.x, FEED.y, FEED.w, FEED.h);
    this.drawCamOccupants();
    const staticAmt = this.camStatic > 0 ? 0.85 : 0.22;
    this.drawStatic(FEED, staticAmt);
    // label bar
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(FEED.x * S, FEED.y * S, FEED.w * S, 36);
    const cam = CAM_LIST.find((c) => c.id === this.camId);
    this.text(`CAM ${this.camId}`, FEED.x * S + 10, FEED.y * S + 8, 16, "#f4f0e6");
    this.text(cam?.name ?? "", FEED.x * S + FEED.w * S - 10, FEED.y * S + 10, 12, "#d0c8b4", "right");
    this.text(`POWER ${Math.ceil(this.power)}%`, FEED.x * S + 10, FEED.y * S + FEED.h * S - 52, 14, "#f4f0e6");
    this.drawUsage(FEED.x * S + 10, FEED.y * S + FEED.h * S - 28);

    this.text(hourLabel(this.hour), 1230, 24, 18, "#f4f0e6", "right");
    this.text(this.isCustom ? "CUSTOM" : `NIGHT ${this.night}`, 1230, 52, 14, "#d01212", "right");

    for (const camInfo of CAM_LIST) {
      const r = mapRect(camInfo.col, camInfo.row);
      const on = camInfo.id === this.camId;
      this.ctx.fillStyle = on ? "#f4f0e6" : "#1a1c24";
      this.ctx.fillRect(r.x * S, r.y * S, r.w * S, r.h * S);
      this.ctx.strokeStyle = on ? "#d01212" : "#3a3d4a";
      this.ctx.lineWidth = 3;
      this.ctx.strokeRect(r.x * S + 1, r.y * S + 1, r.w * S - 2, r.h * S - 2);
      this.text(camInfo.id, r.x * S + r.w * S / 2, r.y * S + 18, 16, on ? "#14080a" : "#f4f0e6", "center");
    }
    this.ctx.fillStyle = "#101218";
    this.ctx.fillRect(YOU.x * S, YOU.y * S, YOU.w * S, YOU.h * S);
    this.ctx.strokeStyle = "#f4f0e6";
    this.ctx.strokeRect(YOU.x * S + 2, YOU.y * S + 2, YOU.w * S - 4, YOU.h * S - 4);
    this.text("DROP CAM", YOU.x * S + YOU.w * S / 2, YOU.y * S + 14, 14, "#f4f0e6", "center");

    // room lines like a floorplan
    this.ctx.strokeStyle = "#3a3d48";
    this.ctx.lineWidth = 2;
    this.ctx.strokeRect(MAP_X * S - 6, MAP_Y * S - 6, 216 * S, 196 * S);
  }

  private drawCamOccupants() {
    const cam = this.camId;
    const movers: Mover[] = ["boxy", "pepper", "crumb"];
    for (const who of movers) {
      if (LOC_CAM[this.loc[who]] !== cam) continue;
      const slot = SLOTS[cam][who];
      if (!slot) continue;
      this.drawSpr(`spr_${who}`, FEED.x + slot[0], FEED.y + slot[1], slot[2]);
    }
    if (cam === "1C" && this.mozzPhase === 1) {
      const peek = this.imgs.mozz_peek;
      if (peek) {
        const h = 70;
        const w = h * (peek.width / peek.height);
        this.blit(peek, FEED.x + 200 - w / 2, FEED.y + 70, w, h);
      }
    }
    if (cam === "1C" && this.mozzPhase === 2) {
      const slot = SLOTS["1C"].mozz;
      if (slot) this.drawSpr("spr_mozz", FEED.x + slot[0], FEED.y + slot[1], slot[2]);
    }
    if (this.mozzPhase === 3 && (cam === "2A" || (cam === "2B" && this.mozzRun < 2.15))) {
      const slot = SLOTS[cam].mozz;
      if (slot) this.drawSpr("spr_mozz", FEED.x + slot[0], FEED.y + slot[1], slot[2]);
    }
  }

  private drawSpr(key: string, feetX: number, feetY: number, height: number) {
    const img = this.imgs[key];
    if (!img) return;
    const aspect = img.width / img.height;
    const w = height * aspect;
    const bob = Math.sin(this.time * 2.2 + key.length) * 1.4;
    this.blit(img, feetX - w / 2, feetY - height + bob, w, height);
  }

  private drawStatic(r: Rect, amt: number) {
    const ctx = this.ctx;
    const count = Math.floor(40 + amt * 220);
    for (let i = 0; i < count; i++) {
      const x = (r.x + Math.random() * r.w) * S;
      const y = (r.y + Math.random() * r.h) * S;
      ctx.fillStyle = Math.random() < 0.5 ? "rgba(255,255,255,0.35)" : "rgba(0,0,0,0.45)";
      ctx.fillRect(x, y, 4 + Math.random() * 10, 3);
    }
    const band = (r.y + ((this.time * 60) % r.h)) * S;
    ctx.fillStyle = "rgba(255,255,255,0.07)";
    ctx.fillRect(r.x * S, band, r.w * S, 4);
    if (amt > 0.5) {
      ctx.fillStyle = `rgba(0,0,0,${0.25 + amt * 0.35})`;
      ctx.fillRect(r.x * S, r.y * S, r.w * S, r.h * S);
    }
  }

  private renderScare() {
    const ctx = this.ctx;
    const who = this.scareWho ?? "boxy";
    const frame = Math.min(3, Math.floor(this.scareT * 12));
    const img = this.imgs[`scare_${who}_${frame}`] ?? this.imgs[`scare_${who}_0`];
    ctx.fillStyle = this.scareT < 0.06 ? "#f4f0e6" : "#050308";
    ctx.fillRect(-30, -30, 1400, 800);
    if (!img) return;
    const grow = 0.9 + this.scareT * 1.55;
    const h = Math.min(980, img.height * grow);
    const w = h * (img.width / img.height);
    const jx = (Math.random() - 0.5) * (28 - this.scareT * 10);
    const jy = (Math.random() - 0.5) * (20 - this.scareT * 8);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, (1280 - w) / 2 + jx, (720 - h) / 2 + 30 + jy, w, h);
    if (Math.sin(this.scareT * 46) > 0) {
      ctx.fillStyle = "rgba(180, 0, 16, 0.22)";
      ctx.fillRect(0, 0, 1280, 720);
    }
  }
}

export function tipFor(night: number, custom: boolean) {
  if (custom) return "Set each animatronic from 0 (asleep) to 20 (relentless). Then start the night.";
  return TIPS[night] ?? TIPS[6];
}
