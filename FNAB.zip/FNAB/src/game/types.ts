export type CharId = "boxy" | "pepper" | "crumb" | "mozz";
export type Mover = "boxy" | "pepper" | "crumb";
export type Loc =
  | "stage"
  | "dining"
  | "parts"
  | "kitchen"
  | "westHall"
  | "westCorner"
  | "eastHall"
  | "eastCorner"
  | "leftDoor"
  | "rightDoor";
export type CamId = "1A" | "1B" | "1C" | "2A" | "2B" | "3A" | "3B" | "4A" | "4B";
export type Screen =
  | "loading"
  | "menu"
  | "custom"
  | "extras"
  | "intro"
  | "play"
  | "scare"
  | "over"
  | "win"
  | "finale";

export type AiSet = Record<CharId, number>;

export type SaveData = {
  v: 1;
  unlocked: number;
  beat: boolean;
  customWins: number;
};

export type Hud = {
  screen: Screen;
  night: number;
  custom: boolean;
  hourLabel: string;
  power: number;
  usage: number;
  camUp: boolean;
  camId: CamId;
  camName: string;
  leftDoor: boolean;
  rightDoor: boolean;
  leftLight: boolean;
  rightLight: boolean;
  powerOut: boolean;
  paused: boolean;
  menuIndex: number;
  customIndex: number;
  ai: AiSet;
  unlocked: number;
  beat: boolean;
  customWins: number;
  quitJoke: boolean;
  scareWho: CharId | null;
  muted: boolean;
};

export const SAVE_KEY = "boxys-nights-v1";

export const NIGHTS: Record<number, AiSet> = {
  1: { boxy: 0, pepper: 4, crumb: 2, mozz: 0 },
  2: { boxy: 2, pepper: 6, crumb: 5, mozz: 2 },
  3: { boxy: 4, pepper: 8, crumb: 7, mozz: 5 },
  4: { boxy: 6, pepper: 11, crumb: 9, mozz: 7 },
  5: { boxy: 8, pepper: 14, crumb: 12, mozz: 10 },
  6: { boxy: 10, pepper: 16, crumb: 14, mozz: 13 },
};

export const DRAIN: Record<number, number> = {
  1: 0.72,
  2: 0.88,
  3: 1,
  4: 1.14,
  5: 1.28,
  6: 1.42,
};

export const HOUR_SECONDS = 42;

export const CAM_LIST: { id: CamId; name: string; col: number; row: number }[] = [
  { id: "1A", name: "SHOW STAGE", col: 0, row: 0 },
  { id: "1B", name: "DINING", col: 1, row: 0 },
  { id: "4A", name: "KITCHEN", col: 2, row: 0 },
  { id: "1C", name: "CURTAIN COVE", col: 0, row: 1 },
  { id: "4B", name: "PARTS ROOM", col: 1, row: 1 },
  { id: "3A", name: "EAST HALL", col: 2, row: 1 },
  { id: "2A", name: "WEST HALL", col: 0, row: 2 },
  { id: "2B", name: "WEST CORNER", col: 1, row: 2 },
  { id: "3B", name: "EAST CORNER", col: 2, row: 2 },
];

export const LOC_CAM: Record<Loc, CamId | null> = {
  stage: "1A",
  dining: "1B",
  parts: "4B",
  kitchen: "4A",
  westHall: "2A",
  westCorner: "2B",
  eastHall: "3A",
  eastCorner: "3B",
  leftDoor: null,
  rightDoor: null,
};

export function hourLabel(hour: number): string {
  if (hour <= 0) return "12 AM";
  if (hour >= 6) return "6 AM";
  return `${hour} AM`;
}

export function readSave(): SaveData {
  const blank: SaveData = { v: 1, unlocked: 1, beat: false, customWins: 0 };
  if (typeof localStorage === "undefined") return blank;
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return blank;
    const p = JSON.parse(raw) as Partial<SaveData>;
    return {
      v: 1,
      unlocked: Math.min(6, Math.max(1, Number(p.unlocked) || 1)),
      beat: Boolean(p.beat),
      customWins: Math.max(0, Number(p.customWins) || 0),
    };
  } catch {
    return blank;
  }
}

export function writeSave(s: SaveData) {
  localStorage.setItem(SAVE_KEY, JSON.stringify(s));
}
