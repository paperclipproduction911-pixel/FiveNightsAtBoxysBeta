import type { CharId } from "./types";

/** Original synthesized effects — no borrowed stingers or melodies. */
export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private fanGain: GainNode | null = null;
  private hissGain: GainNode | null = null;
  muted = false;

  unlock() {
    if (typeof window === "undefined") return;
    if (!this.ctx) this.build();
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.45;
  }

  setFan(on: boolean) {
    this.ramp(this.fanGain, on ? 0.07 : 0, 0.25);
  }

  setCamHiss(on: boolean) {
    this.ramp(this.hissGain, on ? 0.035 : 0, 0.08);
  }

  door() {
    this.noiseBurst(0.26, 700, 0.55, 0.28);
    this.tone(160, 70, 0.22, 0.1, "square");
  }

  light() {
    this.tone(920, 920, 0.04, 0.07, "square");
  }

  click() {
    this.tone(240, 180, 0.04, 0.06, "square");
  }

  cam() {
    this.noiseBurst(0.1, 1600, 0.45, 0.16);
    this.tone(1280, 860, 0.06, 0.05, "square");
  }

  thud(big = false) {
    this.tone(big ? 78 : 120, 50, big ? 0.18 : 0.1, big ? 0.26 : 0.14, "sine");
    this.noiseBurst(0.09, 180, 0.8, big ? 0.16 : 0.07);
  }

  pot() {
    this.tone(340, 220, 0.09, 0.1, "square");
    this.tone(180, 140, 0.12, 0.06, "triangle");
  }

  bang() {
    this.noiseBurst(0.28, 260, 0.4, 0.36);
    this.tone(100, 40, 0.22, 0.28, "sawtooth");
  }

  mozzRun() {
    this.tone(140, 48, 0.55, 0.18, "sawtooth");
    this.noiseBurst(0.4, 480, 0.35, 0.14);
  }

  note(freq: number) {
    this.tone(freq, freq * 0.98, 0.4, 0.07, "square");
  }

  hour() {
    this.tone(523, 523, 0.07, 0.05, "square");
    this.tone(784, 784, 0.09, 0.04, "square");
  }

  heartbeat() {
    this.tone(70, 50, 0.08, 0.12, "sine");
  }

  win() {
    [262, 330, 392, 523, 659].forEach((f, i) => {
      window.setTimeout(() => this.note(f * 1), i * 110);
    });
  }

  jumpscare(who: CharId) {
    const base = { boxy: 68, pepper: 150, crumb: 360, mozz: 110 }[who];
    const type = who === "crumb" ? "square" : who === "pepper" ? "triangle" : "sawtooth";
    this.tone(base * 3.1, Math.max(36, base * 0.42), 0.78, 0.42, type);
    this.tone(base * 2.03, base * 0.9, 0.5, 0.18, "square");
    this.noiseBurst(0.45, who === "mozz" ? 980 : who === "crumb" ? 1400 : 420, 0.28, 0.32);
  }

  private ramp(node: GainNode | null, value: number, t: number) {
    if (!node || !this.ctx) return;
    const now = this.ctx.currentTime;
    node.gain.cancelScheduledValues(now);
    node.gain.linearRampToValueAtTime(value, now + t);
  }

  private build() {
    const ctx = new AudioContext();
    this.ctx = ctx;
    const master = ctx.createGain();
    master.gain.value = this.muted ? 0 : 0.45;
    master.connect(ctx.destination);
    this.master = master;

    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    let s = 0;
    for (let i = 0; i < len; i++) {
      s = (s + (Math.random() * 2 - 1) * 0.18) * 0.94;
      data[i] = Math.max(-1, Math.min(1, s * 2.4));
    }
    this.noise = buf;

    const wireDrone = (freq: number, type: OscillatorType, gain: number) => {
      const o = ctx.createOscillator();
      o.type = type;
      o.frequency.value = freq;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 220;
      const g = ctx.createGain();
      g.gain.value = gain;
      o.connect(filter);
      filter.connect(g);
      g.connect(master);
      o.start();
    };
    wireDrone(49, "sawtooth", 0.04);
    wireDrone(73.4, "triangle", 0.028);
    wireDrone(98, "sine", 0.02);

    const fan = ctx.createBufferSource();
    fan.buffer = buf;
    fan.loop = true;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 260;
    bp.Q.value = 0.65;
    const fg = ctx.createGain();
    fg.gain.value = 0;
    fan.connect(bp);
    bp.connect(fg);
    fg.connect(master);
    fan.start();
    this.fanGain = fg;

    const hiss = ctx.createBufferSource();
    hiss.buffer = buf;
    hiss.loop = true;
    const hp = ctx.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 1400;
    const hg = ctx.createGain();
    hg.gain.value = 0;
    hiss.connect(hp);
    hp.connect(hg);
    hg.connect(master);
    hiss.start();
    this.hissGain = hg;
  }

  private tone(
    f0: number,
    f1: number,
    dur: number,
    gain: number,
    type: OscillatorType,
  ) {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(Math.max(30, f0), now);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(30, f1), now + dur);
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = type === "square" ? 1400 : 900;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);
    o.connect(filter);
    filter.connect(g);
    g.connect(this.master);
    o.start(now);
    o.stop(now + dur + 0.02);
  }

  private noiseBurst(dur: number, freq: number, q: number, gain: number) {
    if (!this.ctx || !this.master || !this.noise) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const f = ctx.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = freq;
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start(now);
    src.stop(now + dur + 0.02);
  }
}
