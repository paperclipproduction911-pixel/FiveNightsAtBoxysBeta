import { useEffect, useRef, useState } from "react";
import { asset } from "./assets";
import { BoxysGame, tipFor } from "./engine";
import { CAM_LIST, type CharId, type Hud } from "./types";

const MENU = [
  { id: "new", label: "NEW GAME" },
  { id: "continue", label: "CONTINUE" },
  { id: "custom", label: "CUSTOM NIGHT" },
  { id: "extras", label: "EXTRAS" },
  { id: "quit", label: "QUIT" },
] as const;

const ROWS: { id: CharId; name: string; line: string }[] = [
  { id: "boxy", name: "BOXY", line: "He's always watching…" },
  { id: "pepper", name: "PEPPER", line: "Don't let him in…" },
  { id: "crumb", name: "CRUMB", line: "He wants your pizza…" },
  { id: "mozz", name: "MOZZ", line: "He's behind the curtain…" },
];

export function Game() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const api = useRef<BoxysGame | null>(null);
  const [hud, setHud] = useState<Hud | null>(null);

  useEffect(() => {
    const style = document.createElement("style");
    style.textContent = `@font-face{font-family:"Press Start 2P";src:url("${asset("/fonts/PressStart2P.ttf")}") format("truetype");font-display:swap;}`;
    document.head.appendChild(style);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new BoxysGame(canvas, setHud);
    api.current = game;
    let dead = false;
    void game.start().then(() => {
      if (dead) game.stop();
    });
    const down = (e: KeyboardEvent) => {
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) {
        e.preventDefault();
      }
      api.current?.onKey(e.code, true, e.repeat);
    };
    const up = (e: KeyboardEvent) => api.current?.onKey(e.code, false, false);
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      dead = true;
      game.stop();
      api.current = null;
      style.remove();
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  const g = () => api.current;
  const screen = hud?.screen ?? "loading";
  const playing = screen === "play" || screen === "scare";

  return (
    <div className="app">
      <div className={`play-shell ${playing ? "live" : "parked"}`}>
        <div className="stage">
          <canvas
            ref={canvasRef}
            width={1280}
            height={720}
            aria-label="Security office at Boxy's Pizza"
          />
          {screen === "play" && hud && (
            <>
              {hud.paused && (
                <div className="pause-card">
                  <h2>PAUSED</h2>
                  <button type="button" onClick={() => g()?.action("resume")}>
                    RESUME
                  </button>
                  <button type="button" onClick={() => g()?.action("retry")}>
                    RETRY NIGHT
                  </button>
                  <button type="button" onClick={() => g()?.action("menu")}>
                    MAIN MENU
                  </button>
                </div>
              )}
            </>
          )}
        </div>
        {screen === "play" && hud && !hud.paused && (
          <div className="touchbar">
            <div className={`readout ${hud.power < 20 ? "low" : ""}`}>
              <span>{hud.hourLabel}</span>
              <span>{hud.custom ? "CUSTOM" : `NIGHT ${hud.night}`}</span>
              <span>PWR {hud.powerOut ? "OUT" : `${hud.power}%`}</span>
            </div>
            {hud.camUp ? (
              <div className="cam-pad">
                {CAM_LIST.map((cam) => (
                  <button
                    key={cam.id}
                    type="button"
                    className={hud.camId === cam.id ? "on" : ""}
                    onClick={() => g()?.selectCam(cam.id)}
                  >
                    {cam.id}
                  </button>
                ))}
                <button type="button" className="drop" onClick={() => g()?.closeCam()}>
                  DROP CAM
                </button>
              </div>
            ) : (
              <div className="door-pad">
                <button
                  type="button"
                  className={hud.leftDoor ? "on door" : "door"}
                  onClick={() => g()?.toggleDoor("L")}
                >
                  LEFT DOOR
                </button>
                <button
                  type="button"
                  className={hud.leftLight ? "on light" : "light"}
                  onPointerDown={(e) => {
                    e.preventDefault();
                    g()?.setLight("L", true);
                  }}
                  onPointerUp={() => g()?.setLight("L", false)}
                  onPointerLeave={() => g()?.setLight("L", false)}
                  onPointerCancel={() => g()?.setLight("L", false)}
                >
                  LIGHT
                </button>
                <button type="button" className="cams" onClick={() => g()?.toggleCam()}>
                  CAMS
                </button>
                <button
                  type="button"
                  className={hud.rightLight ? "on light" : "light"}
                  onPointerDown={(e) => {
                    e.preventDefault();
                    g()?.setLight("R", true);
                  }}
                  onPointerUp={() => g()?.setLight("R", false)}
                  onPointerLeave={() => g()?.setLight("R", false)}
                  onPointerCancel={() => g()?.setLight("R", false)}
                >
                  LIGHT
                </button>
                <button
                  type="button"
                  className={hud.rightDoor ? "on door" : "door"}
                  onClick={() => g()?.toggleDoor("R")}
                >
                  RIGHT DOOR
                </button>
              </div>
            )}
          </div>
        )}
        {playing && <p className="legend">A/D DOORS · HOLD Q/E LIGHTS · SPACE CAMS · 1–9 ROOMS · M MUTE · ESC PAUSE</p>}
      </div>

      {screen === "loading" && (
        <div className="screen-layer boot">
          <p className="boot-title">BOXY'S</p>
        </div>
      )}

      {screen === "menu" && hud && (
        <div className="screen-layer menu-screen">
          <div className="checker top" />
          <header className="menu-grid">
            <img src={asset("/boxys/scare_boxy_0.png")} alt="Boxy, brown bear animatronic in a purple top hat" />
            <div className="menu-copy">
              <p className="kicker">FIVE NIGHTS AT</p>
              <h1>
                BOXY'S
                <i />
              </h1>
              <p className="tag">A NEW NIGHTMARE AWAITS…</p>
              <nav className="menu-list">
                {MENU.map((item, i) => {
                  const disabled = item.id === "continue" && hud.unlocked <= 1 && !hud.beat;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      className={hud.menuIndex === i ? "active" : ""}
                      disabled={disabled}
                      onMouseEnter={() => {
                        /* highlight follows keyboard; hover is CSS */
                      }}
                      onClick={() => g()?.action(item.id)}
                    >
                      <span>{hud.menuIndex === i ? "▶" : ""}</span>
                      {item.label}
                      {item.id === "continue" && hud.unlocked > 1 ? `  N${hud.unlocked}` : ""}
                    </button>
                  );
                })}
              </nav>
              {hud.quitJoke && <p className="joke">THE DOORS LOCK FROM THIS SIDE.</p>}
            </div>
            <aside className="blurb">
              <img src={asset("/boxys/pizza.png")} alt="A slice of pepperoni pizza" />
              <p>6 NIGHTS.</p>
              <p>4 ANIMATRONICS.</p>
              <p>ONE VERY UNLUCKY NIGHT GUARD.</p>
            </aside>
          </header>
          <div className="checker bottom" />
        </div>
      )}

      {screen === "intro" && hud && (
        <div className="screen-layer center-card">
          <p className="kicker">{hud.hourLabel}</p>
          <h1>{hud.custom ? "CUSTOM" : `NIGHT ${hud.night}`}</h1>
          <p className="tip">{tipFor(hud.night, hud.custom)}</p>
          <button type="button" className="solid" onClick={() => g()?.action("begin")}>
            CLOCK IN
          </button>
        </div>
      )}

      {screen === "custom" && hud && (
        <div className="screen-layer custom-screen">
          <h1>CUSTOM NIGHT</h1>
          <p className="tip">AI levels 0–20. Zero stays on stage. Twenty never waits.</p>
          <div className="ai-list">
            {ROWS.map((row, i) => (
              <div key={row.id} className={hud.customIndex === i ? "ai-row active" : "ai-row"}>
                <span>{row.name}</span>
                <button type="button" onClick={() => g()?.bumpAi(row.id, -1)} aria-label={`Lower ${row.name}`}>
                  {"<"}
                </button>
                <b>{String(hud.ai[row.id]).padStart(2, "0")}</b>
                <button type="button" onClick={() => g()?.bumpAi(row.id, 1)} aria-label={`Raise ${row.name}`}>
                  {">"}
                </button>
              </div>
            ))}
          </div>
          <div className="presets">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <button key={n} type="button" onClick={() => g()?.loadPreset(n)}>
                N{n}
              </button>
            ))}
          </div>
          <div className="row-actions">
            <button type="button" className="solid" onClick={() => g()?.startNight(7, true)}>
              START NIGHT
            </button>
            <button type="button" onClick={() => g()?.action("menu")}>
              BACK
            </button>
          </div>
        </div>
      )}

      {screen === "extras" && hud && (
        <div className="screen-layer extras">
          <h1>EXTRAS</h1>
          <div className="cast">
            {ROWS.map((row) => (
              <article key={row.id}>
                <img src={asset(`/boxys/spr_${row.id}.png`)} alt="" />
                <h2>{row.name}</h2>
                <p>{row.line}</p>
              </article>
            ))}
          </div>
          <ul className="help">
            <li>Left door stops Pepper, Mozz, and Boxy if he picked the west hall.</li>
            <li>Right door stops Crumb, and Boxy if he picked the east hall.</li>
            <li>Boxy does not move while you are looking at his camera.</li>
            <li>Mozz builds speed in Curtain Cove when the camera is somewhere else.</li>
            <li>Doors, lights, and the monitor all burn power. At 0%, Boxy comes anyway.</li>
          </ul>
          <div className="presets night-pick">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <button key={n} type="button" disabled={n > hud.unlocked} onClick={() => g()?.startNight(n, false)}>
                NIGHT {n}
              </button>
            ))}
          </div>
          <p className="tip">
            {hud.beat ? "YOU SURVIVED ALL SIX." : `HIGHEST NIGHT UNLOCKED: ${hud.unlocked}`}
            {hud.customWins > 0 ? ` · CUSTOM CLEARS ${hud.customWins}` : ""}
          </p>
          <button type="button" onClick={() => g()?.action("menu")}>
            BACK
          </button>
        </div>
      )}

      {(screen === "over" || screen === "win" || screen === "finale") && hud && (
        <div className="screen-layer center-card end-card">
          {screen === "over" ? (
            <>
              <h1 className="danger">GAME OVER</h1>
              <p className="tip">{hud.scareWho ? `${hud.scareWho.toUpperCase()} GOT IN.` : "TRY AGAIN?"}</p>
              <div className="row-actions">
                <button type="button" className="solid" onClick={() => g()?.action("retry")}>
                  YES
                </button>
                <button type="button" onClick={() => g()?.action("menu")}>
                  NO
                </button>
              </div>
            </>
          ) : (
            <>
              <img className="win-bear" src={asset("/boxys/boxy_win.png")} alt="Boxy giving a thumbs up" />
              {screen === "finale" ? (
                <>
                  <h1>NIGHT 6 COMPLETE!</h1>
                  <p className="tag">YOU SURVIVED… FOR NOW.</p>
                  <p className="tip">6 NIGHTS. 4 ANIMATRONICS. ONE VERY UNLUCKY NIGHT GUARD.</p>
                </>
              ) : (
                <>
                  <h1>{hud.custom ? "CUSTOM" : `NIGHT ${hud.night}`}</h1>
                  <p className="tag">COMPLETE!</p>
                  <p className="tip">YOU SURVIVED… FOR NOW.</p>
                </>
              )}
              <button type="button" className="solid" onClick={() => g()?.action("next")}>
                {screen === "win" && !hud.custom && hud.night < 6 ? "NEXT NIGHT" : "MENU"}
              </button>
            </>
          )}
        </div>
      )}

      <button type="button" className="mute" onClick={() => g()?.toggleMute()} aria-label={hud?.muted ? "Unmute" : "Mute"}>
        {hud?.muted ? "SOUND OFF" : "SOUND ON"}
      </button>
    </div>
  );
}
