#!/usr/bin/env python3
"""Pixel-art assets for Five Nights at Boxy's. Original characters only."""
from __future__ import annotations

import json
import math
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFont

OUT = "/workspace/public/boxys"
FONT_PATH = "/workspace/public/fonts/PressStart2P.ttf"
os.makedirs(OUT, exist_ok=True)

# --- palette ---
OUTL = (8, 6, 10, 255)
FUR = (186, 104, 52, 255)
FUR_D = (128, 64, 32, 255)
FUR_S = (92, 44, 24, 255)
MUZ = (236, 204, 160, 255)
MUZ_D = (196, 154, 112, 255)
EYE = (248, 248, 252, 255)
PUP = (10, 8, 12, 255)
NOSE = (28, 16, 20, 255)
TEETH = (248, 244, 236, 255)
MOUTH = (48, 12, 18, 255)
HAT = (108, 52, 168, 255)
HAT_D = (64, 28, 112, 255)
HAT_B = (36, 16, 64, 255)
BOW = (132, 56, 188, 255)
BOW_D = (78, 28, 120, 255)
RED = (176, 36, 40, 255)
EAR_IN = (120, 48, 42, 255)
YEL = (236, 196, 48, 255)
YEL_D = (196, 140, 28, 255)
BEAK = (232, 132, 36, 255)
BEAK_D = (176, 84, 20, 255)
PURP = (150, 96, 186, 255)
PURP_D = (96, 52, 130, 255)
PURP_S = (58, 28, 84, 255)
PINK = (232, 150, 186, 255)
PINK_D = (196, 96, 140, 255)
MAG = (186, 92, 168, 255)
MAG_D = (124, 48, 112, 255)
MAG_S = (78, 28, 72, 255)
BIB = (244, 240, 232, 255)
WALL = (26, 28, 52, 255)
WALL_D = (16, 18, 34, 255)
BRICK = (34, 32, 62, 255)
FLOOR = (18, 14, 20, 255)
WOOD = (92, 58, 36, 255)
WOOD_D = (62, 38, 24, 255)
WOOD_L = (124, 82, 48, 255)
METAL = (70, 74, 84, 255)
METAL_D = (36, 38, 48, 255)
METAL_L = (150, 156, 168, 255)
CHK_R = (168, 36, 40, 255)
CHK_W = (220, 214, 206, 255)
DARK = (6, 6, 10, 255)
GREEN = (64, 220, 96, 255)
CURTAIN = (92, 28, 48, 255)
CURTAIN_D = (48, 12, 28, 255)


def font(sz: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_PATH, sz)


def ell(d: ImageDraw.ImageDraw, cx, cy, rx, ry, fill, outline=None, ow=2):
    box = [cx - rx, cy - ry, cx + rx, cy + ry]
    if outline is not None and ow > 0:
        d.ellipse(
            [box[0] - ow, box[1] - ow, box[2] + ow, box[3] + ow],
            fill=outline,
        )
    d.ellipse(box, fill=fill)


def rect(d, x, y, w, h, fill, outline=None, ow=1):
    if outline is not None:
        d.rectangle([x - ow, y - ow, x + w + ow - 1, y + h + ow - 1], fill=outline)
    d.rectangle([x, y, x + w - 1, y + h - 1], fill=fill)


def speckle(im: Image.Image, chance: float, color, seed: int, only_opaque=True):
    arr = np.array(im)
    rng = np.random.default_rng(seed)
    mask = rng.random(arr.shape[:2]) < chance
    if only_opaque:
        mask &= arr[:, :, 3] > 200
    arr[mask, 0] = color[0]
    arr[mask, 1] = color[1]
    arr[mask, 2] = color[2]
    return Image.fromarray(arr)


def outline_sprite(im: Image.Image, color=OUTL) -> Image.Image:
    arr = np.array(im)
    a = arr[:, :, 3] > 30
    dil = np.zeros_like(a)
    dil[1:, :] |= a[:-1, :]
    dil[:-1, :] |= a[1:, :]
    dil[:, 1:] |= a[:, :-1]
    dil[:, :-1] |= a[:, 1:]
    edge = dil & ~a
    out = arr.copy()
    out[edge] = color
    return Image.fromarray(out)


def new(w, h, color=(0, 0, 0, 0)) -> Image.Image:
    return Image.new("RGBA", (w, h), color)


def brick_wall(d, x0, y0, x1, y1, base, mortar):
    d.rectangle([x0, y0, x1, y1], fill=base)
    h = 8
    y = y0
    row = 0
    while y < y1:
        off = 0 if row % 2 == 0 else 11
        x = x0 + off
        while x < x1:
            d.rectangle([x, y, min(x1, x + 20), min(y1, y + h - 1)], outline=mortar)
            x += 22
        y += h
        row += 1


def checker_band(d, x0, y0, x1, y1, cw=10, ch=8):
    for y in range(y0, y1, ch):
        for x in range(x0, x1, cw):
            c = CHK_R if ((x // cw) + (y // ch)) % 2 == 0 else CHK_W
            d.rectangle([x, y, min(x1, x + cw) - 1, min(y1, y + ch) - 1], fill=c)


def perspective_floor(im, y0, y1, c1, c2, cols=12, rows=8, inset=30):
    """Trapezoid checker. im is RGBA."""
    d = ImageDraw.Draw(im)
    w = im.width
    for r in range(rows):
        t0 = r / rows
        t1 = (r + 1) / rows
        # more rows visually near the camera
        z0 = t0 ** 1.35
        z1 = t1 ** 1.35
        yy0 = y0 + (y1 - y0) * z0
        yy1 = y0 + (y1 - y0) * z1
        left0 = inset * (1 - z0)
        right0 = w - inset * (1 - z0)
        left1 = inset * (1 - z1)
        right1 = w - inset * (1 - z1)
        for c in range(cols):
            u0 = c / cols
            u1 = (c + 1) / cols
            poly = [
                (left0 + (right0 - left0) * u0, yy0),
                (left0 + (right0 - left0) * u1, yy0),
                (left1 + (right1 - left1) * u1, yy1),
                (left1 + (right1 - left1) * u0, yy1),
            ]
            col = c1 if (c + r) % 2 == 0 else c2
            d.polygon(poly, fill=col)


def teeth_row(d, cx, cy, count, tw, th, gap, open_h, s=1):
    total = count * tw + (count - 1) * gap
    x = cx - total / 2
    d.rectangle([cx - total / 2 - 2, cy, cx + total / 2 + 2, cy + open_h], fill=MOUTH)
    for i in range(count):
        d.rectangle([x, cy, x + tw - 1, cy + th], fill=TEETH)
        d.rectangle([x, cy + open_h - th, x + tw - 1, cy + open_h], fill=TEETH)
        x += tw + gap


def draw_eyes(d, cx, cy, sep, rx, ry, scare, look=0):
    for sgn in (-1, 1):
        ex = cx + sgn * sep
        ell(d, ex, cy, rx + scare * 1.4, ry + scare * 2.2, EYE, OUTL, 2)
        # pupil drifts apart when screaming
        px = ex + look * sgn + scare * sgn * 0.4
        py = cy + 1 + scare * 0.3
        ell(d, px, py, max(2, rx * 0.34), max(3, ry * 0.42 + scare), PUP, None, 0)
        # catchlight
        d.rectangle([ex - rx * 0.45, cy - ry * 0.55, ex - rx * 0.45 + 3, cy - ry * 0.55 + 3], fill=(255, 255, 255, 255))


def draw_bowtie(d, cx, cy, s, color, dark):
    ell(d, cx - 16 * s, cy, 14 * s, 9 * s, color, OUTL, 2)
    ell(d, cx + 16 * s, cy, 14 * s, 9 * s, color, OUTL, 2)
    ell(d, cx, cy, 6 * s, 6 * s, dark, OUTL, 2)


def draw_top_hat(d, cx, cy, s):
    # brim
    rect(d, cx - 34 * s, cy - 6 * s, 68 * s, 12 * s, HAT, OUTL, 2)
    # crown
    rect(d, cx - 22 * s, cy - 46 * s, 44 * s, 44 * s, HAT, OUTL, 2)
    rect(d, cx - 22 * s, cy - 18 * s, 44 * s, 8 * s, HAT_D, None, 0)
    # band shine
    d.rectangle([cx - 18 * s, cy - 40 * s, cx - 10 * s, cy - 14 * s], fill=(160, 110, 210, 180))


def cheek_lines(d, cx, cy, s, side_span):
    for sgn in (-1, 1):
        x0 = cx + sgn * (18 * s)
        for i, yy in enumerate((cy + 2 * s, cy + 8 * s, cy + 14 * s)):
            length = (10 - i * 2) * s
            x1 = x0 + sgn * length
            d.line([(x0, yy), (x1, yy)], fill=OUTL, width=max(2, int(2 * s)))


def draw_boxy(scare=0, thumb=False) -> Image.Image:
    w, h = 360, 420
    im = new(w, h)
    d = ImageDraw.Draw(im)
    cx, cy, s = 180, 168, 1.35 + scare * 0.03
    # ears
    ell(d, cx - 58 * s, cy - 46 * s, 28 * s, 28 * s, FUR_D, OUTL, 3)
    ell(d, cx + 58 * s, cy - 46 * s, 28 * s, 28 * s, FUR_D, OUTL, 3)
    ell(d, cx - 58 * s, cy - 46 * s, 14 * s, 14 * s, EAR_IN, None, 0)
    ell(d, cx + 58 * s, cy - 46 * s, 14 * s, 14 * s, EAR_IN, None, 0)
    # head
    ell(d, cx, cy + 6, 78 * s, 70 * s, FUR, OUTL, 3)
    # hat sits on top
    draw_top_hat(d, cx, cy - 58 * s, s)
    # muzzle
    ell(d, cx, cy + 28 * s, 40 * s, 30 * s, MUZ, OUTL, 2)
    ell(d, cx, cy + 18 * s, 12 * s, 9 * s, NOSE, OUTL, 2)
    # brows
    d.polygon(
        [
            (cx - 62 * s, cy - 28 * s),
            (cx - 10 * s, cy - 18 * s - scare * 4),
            (cx - 10 * s, cy - 8 * s),
            (cx - 62 * s, cy - 16 * s),
        ],
        fill=OUTL,
    )
    d.polygon(
        [
            (cx + 62 * s, cy - 28 * s),
            (cx + 10 * s, cy - 18 * s - scare * 4),
            (cx + 10 * s, cy - 8 * s),
            (cx + 62 * s, cy - 16 * s),
        ],
        fill=OUTL,
    )
    draw_eyes(d, cx, cy - 8 * s, 28 * s, 14 * s, 16 * s, scare, look=1)
    cheek_lines(d, cx, cy + 10 * s, s * 0.9, 20)
    open_h = 16 + scare * 18
    teeth_row(d, cx, cy + 36 * s, 7, 7, 8 + scare * 2, 2, open_h, s)
    # jaw shadow
    d.arc(
        [cx - 40 * s, cy + 20 * s, cx + 40 * s, cy + 64 * s],
        20,
        160,
        fill=MUZ_D,
        width=3,
    )
    # torso
    body_top = cy + 78 * s
    ell(d, cx, body_top + 70, 70 * s, 78, FUR, OUTL, 3)
    rect(d, cx - 54 * s, body_top + 10, 108 * s, 40, FUR, None, 0)
    # belly patch
    ell(d, cx, body_top + 78, 36 * s, 40, MUZ_D, OUTL, 2)
    draw_bowtie(d, cx, body_top + 8, s, BOW, BOW_D)
    # arms
    if thumb:
        # left arm down, right arm thumb up
        ell(d, cx - 78 * s, body_top + 60, 18 * s, 40, FUR_D, OUTL, 2)
        ell(d, cx + 78 * s, body_top + 8, 16 * s, 34, FUR, OUTL, 2)
        # glove
        ell(d, cx + 78 * s, body_top - 28, 16 * s, 14 * s, (236, 232, 226, 255), OUTL, 2)
        d.polygon(
            [
                (cx + 70 * s, body_top - 40),
                (cx + 78 * s, body_top - 78),
                (cx + 92 * s, body_top - 40),
            ],
            fill=(236, 232, 226, 255),
        )
        d.line(
            [(cx + 78 * s, body_top - 70), (cx + 78 * s, body_top - 36)],
            fill=OUTL,
            width=2,
        )
    else:
        ell(d, cx - 82 * s, body_top + 48, 16 * s, 36, FUR_D, OUTL, 2)
        ell(d, cx + 82 * s, body_top + 48, 16 * s, 36, FUR_D, OUTL, 2)
    im = speckle(im, 0.05, FUR_S, 3 + scare)
    return outline_sprite(im)


def draw_pepper(scare=0) -> Image.Image:
    w, h = 360, 460
    im = new(w, h)
    d = ImageDraw.Draw(im)
    cx, cy, s = 180, 200, 1.28
    # long ears
    for sgn in (-1, 1):
        ex = cx + sgn * 48 * s
        d.rounded_rectangle(
            [ex - 16 * s, cy - 168 * s, ex + 16 * s, cy - 20 * s],
            radius=14,
            fill=OUTL,
        )
        d.rounded_rectangle(
            [ex - 12 * s, cy - 160 * s, ex + 12 * s, cy - 28 * s],
            radius=12,
            fill=PURP,
        )
        d.rounded_rectangle(
            [ex - 6 * s, cy - 150 * s, ex + 6 * s, cy - 40 * s],
            radius=8,
            fill=PINK,
        )
    # head
    ell(d, cx, cy, 72 * s, 64 * s, PURP, OUTL, 3)
    ell(d, cx, cy + 22 * s, 34 * s, 26 * s, PINK, OUTL, 2)
    ell(d, cx, cy + 12 * s, 10 * s, 7 * s, NOSE, OUTL, 2)
    # brows
    d.polygon(
        [(cx - 58 * s, cy - 30 * s), (cx - 12 * s, cy - 16 * s), (cx - 14 * s, cy - 6 * s), (cx - 58 * s, cy - 16 * s)],
        fill=OUTL,
    )
    d.polygon(
        [(cx + 58 * s, cy - 30 * s), (cx + 12 * s, cy - 16 * s), (cx + 14 * s, cy - 6 * s), (cx + 58 * s, cy - 16 * s)],
        fill=OUTL,
    )
    draw_eyes(d, cx, cy - 6 * s, 26 * s, 13 * s, 16 * s, scare, look=-1)
    open_h = 14 + scare * 16
    teeth_row(d, cx, cy + 30 * s, 6, 7, 7, 2, open_h)
    # body
    bt = cy + 72 * s
    ell(d, cx, bt + 78, 58 * s, 80, PURP_D, OUTL, 3)
    rect(d, cx - 40 * s, bt, 80 * s, 36, PURP, None, 0)
    draw_bowtie(d, cx, bt + 4, s * 0.95, RED, (110, 16, 24, 255))
    ell(d, cx - 74 * s, bt + 50, 14 * s, 40, PURP_S, OUTL, 2)
    ell(d, cx + 74 * s, bt + 50, 14 * s, 40, PURP_S, OUTL, 2)
    im = speckle(im, 0.045, PURP_S, 11 + scare)
    return outline_sprite(im)


def draw_crumb(scare=0) -> Image.Image:
    w, h = 360, 440
    im = new(w, h)
    d = ImageDraw.Draw(im)
    cx, cy, s = 180, 150, 1.3
    # tuft
    d.polygon(
        [(cx, cy - 92 * s), (cx - 16 * s, cy - 52 * s), (cx + 10 * s, cy - 60 * s)],
        fill=YEL,
    )
    d.polygon(
        [(cx + 8, cy - 88 * s), (cx + 4, cy - 52 * s), (cx + 26 * s, cy - 64 * s)],
        fill=YEL_D,
    )
    # head
    ell(d, cx, cy, 76 * s, 68 * s, YEL, OUTL, 3)
    # eyes huge
    draw_eyes(d, cx, cy - 16 * s, 28 * s, 16 * s, 18 * s, scare, look=0)
    # brows high (surprised chicken)
    d.arc([cx - 58 * s, cy - 58 * s, cx - 8 * s, cy - 20 * s], 200, 340, fill=OUTL, width=4)
    d.arc([cx + 8 * s, cy - 58 * s, cx + 58 * s, cy - 20 * s], 200, 340, fill=OUTL, width=4)
    # beak open
    open_h = 18 + scare * 22
    by = cy + 18 * s
    d.polygon(
        [
            (cx - 28 * s, by),
            (cx + 28 * s, by),
            (cx + 10 * s, by + 16 * s),
            (cx - 10 * s, by + 16 * s),
        ],
        fill=BEAK,
    )
    d.rectangle([cx - 24 * s, by + 14 * s, cx + 24 * s, by + 14 * s + open_h], fill=MOUTH)
    d.polygon(
        [
            (cx - 30 * s, by + 14 * s + open_h),
            (cx + 30 * s, by + 14 * s + open_h),
            (cx + 8 * s, by + 14 * s + open_h + 16),
            (cx - 8 * s, by + 14 * s + open_h + 16),
        ],
        fill=BEAK_D,
    )
    # little teeth because he's an animatronic, not a real bird
    if scare > 0:
        for i in range(-2, 3):
            d.rectangle(
                [cx + i * 8 * s - 2, by + 14 * s, cx + i * 8 * s + 3, by + 14 * s + 6 + scare],
                fill=TEETH,
            )
    # body
    bt = cy + 78 * s
    ell(d, cx, bt + 80, 74 * s, 78, YEL_D, OUTL, 3)
    # bib
    d.rounded_rectangle(
        [cx - 48 * s, bt + 8, cx + 48 * s, bt + 108],
        radius=8,
        fill=BIB,
        outline=OUTL,
        width=2,
    )
    f = font(15 if scare < 2 else 16)
    label = "LET'S\nEAT!" if True else "EAT!"
    # manual two lines centered
    for i, line in enumerate(["LET'S", "EAT!"]):
        bbox = d.textbbox((0, 0), line, font=f)
        tw = bbox[2] - bbox[0]
        col = (120, 36, 140, 255) if i == 0 else RED
        d.text((cx - tw / 2, bt + 22 + i * 28), line, font=f, fill=col)
    # wings
    ell(d, cx - 88 * s, bt + 58, 22 * s, 16 * s, YEL, OUTL, 2)
    ell(d, cx + 88 * s, bt + 58, 22 * s, 16 * s, YEL, OUTL, 2)
    # feet
    ell(d, cx - 28 * s, bt + 156, 20 * s, 8 * s, BEAK, OUTL, 2)
    ell(d, cx + 28 * s, bt + 156, 20 * s, 8 * s, BEAK, OUTL, 2)
    im = speckle(im, 0.04, YEL_D, 21 + scare)
    return outline_sprite(im)


def draw_mozz(scare=0) -> Image.Image:
    w, h = 380, 440
    im = new(w, h)
    d = ImageDraw.Draw(im)
    cx, cy, s = 190, 180, 1.25
    # huge ears
    ell(d, cx - 78 * s, cy - 10 * s, 52 * s, 58 * s, MAG_D, OUTL, 3)
    ell(d, cx + 78 * s, cy - 10 * s, 52 * s, 58 * s, MAG_D, OUTL, 3)
    ell(d, cx - 78 * s, cy - 10 * s, 30 * s, 36 * s, PINK, None, 0)
    ell(d, cx + 78 * s, cy - 10 * s, 30 * s, 36 * s, PINK, None, 0)
    # head
    ell(d, cx, cy + 10, 64 * s, 60 * s, MAG, OUTL, 3)
    # snout
    ell(d, cx, cy + 28 * s, 28 * s, 22 * s, PINK, OUTL, 2)
    ell(d, cx - 8 * s, cy + 22 * s, 4 * s, 4 * s, NOSE, None, 0)
    ell(d, cx + 8 * s, cy + 22 * s, 4 * s, 4 * s, NOSE, None, 0)
    d.polygon(
        [(cx - 46 * s, cy - 24 * s), (cx - 8 * s, cy - 10 * s), (cx - 10 * s, cy), (cx - 46 * s, cy - 8 * s)],
        fill=OUTL,
    )
    d.polygon(
        [(cx + 46 * s, cy - 24 * s), (cx + 8 * s, cy - 10 * s), (cx + 10 * s, cy), (cx + 46 * s, cy - 8 * s)],
        fill=OUTL,
    )
    draw_eyes(d, cx, cy - 8 * s, 24 * s, 13 * s, 15 * s, scare, look=2)
    # buck teeth
    open_h = 10 + scare * 14
    d.rectangle([cx - 16 * s, cy + 36 * s, cx + 16 * s, cy + 36 * s + open_h], fill=MOUTH)
    tw = 10
    d.rectangle([cx - 12 * s, cy + 34 * s, cx - 12 * s + tw, cy + 34 * s + 16 + scare * 8], fill=TEETH)
    d.rectangle([cx + 2 * s, cy + 34 * s, cx + 2 * s + tw, cy + 34 * s + 16 + scare * 8], fill=TEETH)
    # body smaller
    bt = cy + 78 * s
    ell(d, cx, bt + 70, 50 * s, 72, MAG_D, OUTL, 3)
    draw_bowtie(d, cx, bt + 6, s * 0.9, RED, (110, 16, 24, 255))
    ell(d, cx - 64 * s, bt + 48, 12 * s, 34, MAG_S, OUTL, 2)
    ell(d, cx + 64 * s, bt + 48, 12 * s, 34, MAG_S, OUTL, 2)
    im = speckle(im, 0.05, MAG_S, 31 + scare)
    return outline_sprite(im)


def draw_mozz_peek() -> Image.Image:
    im = new(220, 180)
    d = ImageDraw.Draw(im)
    # two eyes and ears barely through a gap
    ell(d, 70, 90, 36, 40, MAG, OUTL, 2)
    ell(d, 150, 90, 36, 40, MAG, OUTL, 2)
    ell(d, 70, 90, 18, 22, PINK, None, 0)
    ell(d, 150, 90, 18, 22, PINK, None, 0)
    ell(d, 96, 110, 16, 14, EYE, OUTL, 2)
    ell(d, 128, 110, 16, 14, EYE, OUTL, 2)
    ell(d, 100, 112, 5, 6, PUP, None, 0)
    ell(d, 132, 112, 5, 6, PUP, None, 0)
    return outline_sprite(im)


def draw_pizza() -> Image.Image:
    im = new(220, 260)
    d = ImageDraw.Draw(im)
    # slice pointing up-right
    d.polygon([(20, 230), (200, 30), (200, 230)], fill=(214, 168, 64, 255))
    d.polygon([(36, 214), (184, 54), (184, 214)], fill=(236, 206, 96, 255))
    d.line([(20, 230), (200, 30), (200, 230), (20, 230)], fill=(120, 64, 28, 255), width=8)
    for cx, cy, r in (
        (150, 90, 16),
        (150, 140, 18),
        (110, 170, 15),
        (160, 190, 14),
        (100, 120, 12),
    ):
        ell(d, cx, cy, r, r * 0.86, (168, 32, 32, 255), (110, 16, 16, 255), 2)
    return im


def draw_fan(frame: int) -> Image.Image:
    im = new(96, 96)
    d = ImageDraw.Draw(im)
    ell(d, 48, 48, 40, 40, (20, 22, 28, 255), METAL_L, 3)
    ell(d, 48, 48, 8, 8, METAL_L, None, 0)
    ang = frame * (math.pi / 2) + 0.2
    for k in range(3):
        a = ang + k * (2 * math.pi / 3)
        x2 = 48 + math.cos(a) * 30
        y2 = 48 + math.sin(a) * 30
        x3 = 48 + math.cos(a + 0.5) * 14
        y3 = 48 + math.sin(a + 0.5) * 14
        d.polygon([(48, 48), (x2, y2), (x3, y3)], fill=(180, 186, 196, 255))
    # cage lines
    d.arc([10, 10, 86, 86], 0, 360, fill=METAL, width=2)
    d.line([(48, 10), (48, 86)], fill=(40, 42, 52, 180), width=1)
    d.line([(10, 48), (86, 48)], fill=(40, 42, 52, 180), width=1)
    return im


def draw_door() -> Image.Image:
    im = new(92, 200, (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 91, 199], fill=(58, 62, 72, 255))
    d.rectangle([4, 4, 87, 195], fill=(78, 84, 96, 255))
    for y in (8, 56, 104, 152):
        d.rectangle([10, y, 81, y + 40], fill=(48, 52, 62, 255), outline=(24, 26, 32, 255))
        d.rectangle([14, y + 4, 77, y + 18], fill=(110, 116, 128, 255))
    # warning stripe at bottom
    for i in range(0, 92, 10):
        c = YEL if (i // 10) % 2 == 0 else (40, 40, 48, 255)
        d.rectangle([i, 186, i + 9, 198], fill=c)
    return im


def draw_hall(flip: bool) -> Image.Image:
    im = new(92, 200, (12, 10, 16, 255))
    d = ImageDraw.Draw(im)
    # lit corridor receding
    d.polygon([(0, 0), (92, 0), (78, 200), (14, 200)], fill=(46, 40, 58, 255))
    d.polygon([(8, 0), (84, 0), (70, 200), (22, 200)], fill=(62, 54, 78, 255))
    # floor
    d.polygon([(22, 130), (70, 130), (86, 199), (6, 199)], fill=(32, 28, 36, 255))
    # checker bits
    for i, x in enumerate(range(10, 80, 14)):
        c = CHK_R if i % 2 == 0 else CHK_W
        d.polygon([(x, 150), (x + 12, 150), (x + 18, 198), (x + 2, 198)], fill=c)
    # ceiling lamp
    d.rectangle([30, 8, 62, 18], fill=(240, 230, 190, 255))
    d.polygon([(30, 18), (62, 18), (78, 70), (14, 70)], fill=(255, 244, 210, 40))
    # side poster
    d.rectangle([6, 36, 24, 78], fill=(150, 40, 40, 255))
    if flip:
        im = im.transpose(Image.FLIP_LEFT_RIGHT)
    return im


def draw_office() -> Image.Image:
    im = new(640, 360, (8, 8, 12, 255))
    d = ImageDraw.Draw(im)
    # ceiling
    d.rectangle([0, 0, 639, 36], fill=(14, 12, 22, 255))
    d.rectangle([230, 4, 410, 16], fill=(230, 226, 200, 255))
    d.rectangle([238, 16, 402, 22], fill=(90, 88, 70, 255))
    # glow
    d.polygon([(230, 22), (410, 22), (460, 70), (180, 70)], fill=(255, 244, 210, 28))
    # back wall
    brick_wall(d, 0, 28, 639, 228, (24, 26, 48, 255), (16, 18, 32, 255))
    # side shading
    d.rectangle([0, 28, 70, 250], fill=(16, 16, 30, 90))
    d.rectangle([570, 28, 639, 250], fill=(16, 16, 30, 90))
    # doorway holes
    d.rectangle([6, 46, 98, 246], fill=(4, 4, 8, 255))
    d.rectangle([542, 46, 634, 246], fill=(4, 4, 8, 255))
    # door frames
    d.rectangle([0, 40, 104, 252], outline=(12, 10, 16, 255), width=6)
    d.rectangle([536, 40, 639, 252], outline=(12, 10, 16, 255), width=6)
    # checker trim
    checker_band(d, 108, 214, 532, 230, 12, 8)
    # poster
    d.rectangle([132, 48, 210, 150], fill=(240, 232, 220, 255), outline=OUTL, width=2)
    d.rectangle([138, 54, 204, 78], fill=RED)
    f = font(8)
    d.text((144, 58), "BOXY'S", font=f, fill=(255, 244, 230, 255))
    d.text((146, 72), "PIZZA", font=f, fill=YEL)
    # mini bear head on poster
    ell(d, 171, 112, 22, 20, FUR, OUTL, 2)
    ell(d, 156, 98, 8, 8, FUR_D, OUTL, 1)
    ell(d, 186, 98, 8, 8, FUR_D, OUTL, 1)
    rect(d, 160, 78, 22, 16, HAT, None, 0)
    ell(d, 164, 110, 4, 5, EYE, None, 0)
    ell(d, 178, 110, 4, 5, EYE, None, 0)
    d.rectangle([162, 122, 180, 128], fill=TEETH)
    # vent
    d.rectangle([360, 52, 460, 100], fill=(20, 22, 28, 255), outline=METAL, width=2)
    for y in range(58, 96, 8):
        d.rectangle([366, y, 454, y + 3], fill=(50, 54, 64, 255))
    # tiny warning sign
    d.rectangle([470, 58, 520, 96], fill=YEL, outline=OUTL)
    d.text((478, 68), "!", font=font(16), fill=(20, 20, 20, 255))
    # floor
    d.rectangle([0, 228, 639, 359], fill=(14, 12, 16, 255))
    perspective_floor(im, 230, 359, (22, 18, 24, 255), (32, 26, 30, 255), cols=14, rows=7, inset=8)
    # desk
    d.polygon([(70, 176), (570, 176), (620, 248), (20, 248)], fill=WOOD_D)
    d.polygon([(70, 176), (570, 176), (548, 196), (92, 196)], fill=WOOD_L)
    d.rectangle([40, 236, 600, 268], fill=WOOD)
    # drawers
    d.rectangle([48, 248, 130, 300], fill=WOOD_D, outline=(30, 18, 12, 255))
    d.rectangle([510, 248, 592, 300], fill=WOOD_D, outline=(30, 18, 12, 255))
    d.rectangle([78, 268, 100, 276], fill=METAL_L)
    d.rectangle([540, 268, 562, 276], fill=METAL_L)
    # monitors
    for mx in (150, 430):
        d.rectangle([mx, 150, mx + 78, 200], fill=(8, 12, 16, 255), outline=METAL, width=2)
        d.rectangle([mx + 6, 156, mx + 72, 188], fill=(16, 36, 28, 255))
        d.rectangle([mx + 30, 200, mx + 48, 214], fill=METAL_D)
        # scanline
        d.rectangle([mx + 10, 168, mx + 66, 170], fill=(40, 90, 60, 255))
    # keyboard
    d.rectangle([250, 206, 390, 222], fill=(24, 24, 28, 255), outline=METAL_D)
    for i in range(12):
        d.rectangle([256 + i * 11, 210, 264 + i * 11, 218], fill=(48, 48, 56, 255))
    # cup
    d.rectangle([400, 188, 422, 214], fill=RED, outline=OUTL)
    d.rectangle([398, 186, 424, 192], fill=(220, 220, 220, 255))
    d.ellipse([406, 196, 412, 204], fill=(240, 240, 240, 255))
    # papers
    d.rectangle([196, 198, 236, 214], fill=(230, 226, 210, 255))
    d.line([(200, 202), (230, 202)], fill=(180, 60, 60, 255), width=1)
    d.line([(200, 206), (226, 206)], fill=(40, 40, 40, 255), width=1)
    # button backplates
    for x, y in ((104, 56), (104, 104), (482, 56), (482, 104)):
        d.rectangle([x - 4, y - 4, x + 58, y + 46], fill=(12, 12, 18, 255), outline=(40, 40, 52, 255))
    # cam tablet slot on desk front
    d.rectangle([260, 292, 380, 344], fill=(10, 12, 16, 255), outline=METAL)
    d.rectangle([270, 302, 370, 332], fill=(20, 28, 24, 255))
    # wall grime
    im = speckle(im, 0.03, (10, 8, 16, 255), 99, only_opaque=True)
    return im


def room_base(title_color=None) -> Image.Image:
    im = new(400, 250, (10, 10, 14, 255))
    return im


def draw_stage() -> Image.Image:
    im = room_base()
    d = ImageDraw.Draw(im)
    brick_wall(d, 0, 0, 399, 150, (32, 18, 28, 255), (20, 10, 16, 255))
    # curtains
    for x in range(0, 70, 10):
        d.rectangle([x, 0, x + 8, 168], fill=CURTAIN if (x // 10) % 2 == 0 else CURTAIN_D)
    for x in range(330, 400, 10):
        d.rectangle([x, 0, x + 8, 168], fill=CURTAIN if (x // 10) % 2 == 0 else CURTAIN_D)
    d.rectangle([0, 0, 399, 18], fill=CURTAIN_D)
    f = font(10)
    d.text((118, 28), "BOXY'S BAND", font=f, fill=YEL)
    # spotlights
    for sx in (90, 200, 310):
        d.polygon([(sx, 18), (sx + 16, 18), (sx + 40, 120), (sx - 24, 120)], fill=(255, 244, 200, 36))
        d.rectangle([sx, 16, sx + 16, 24], fill=(240, 240, 220, 255))
    # stage planks
    d.rectangle([0, 168, 399, 249], fill=(72, 46, 30, 255))
    for y in range(176, 250, 12):
        d.line([(0, y), (399, y)], fill=(50, 30, 20, 255), width=2)
    checker_band(d, 0, 160, 399, 172, 10, 6)
    # stars
    for sx, sy in ((80, 50), (200, 46), (300, 60), (140, 80)):
        d.rectangle([sx, sy, sx + 3, sy + 3], fill=YEL)
    return speckle(im, 0.04, (20, 10, 16, 255), 7)


def draw_dining() -> Image.Image:
    im = room_base()
    d = ImageDraw.Draw(im)
    brick_wall(d, 0, 0, 399, 110, (22, 26, 48, 255), (12, 14, 28, 255))
    # windows
    for x in (30, 300):
        d.rectangle([x, 28, x + 70, 78], fill=(180, 190, 210, 255), outline=(20, 20, 30, 255), width=3)
        d.line([(x + 35, 28), (x + 35, 78)], fill=(20, 20, 30, 255), width=2)
        d.line([(x, 52), (x + 70, 52)], fill=(20, 20, 30, 255), width=2)
    # banner
    d.polygon([(120, 16), (200, 28), (280, 16), (270, 36), (200, 46), (130, 36)], fill=RED)
    d.text((158, 24), "PARTY", font=font(8), fill=CHK_W)
    perspective_floor(im, 120, 249, (28, 24, 32, 255), (48, 36, 40, 255), cols=10, rows=6, inset=10)
    # tables
    for tx, ty, tw in ((70, 150, 70), (170, 140, 80), (280, 156, 70), (120, 190, 64), (230, 196, 72)):
        d.ellipse([tx, ty, tx + tw, ty + 22], fill=(90, 40, 40, 255), outline=OUTL)
        d.rectangle([tx + tw // 2 - 4, ty + 16, tx + tw // 2 + 4, ty + 36], fill=WOOD_D)
        # pizza
        ell(d, tx + tw // 2, ty + 10, 10, 6, YEL, None, 0)
    # chairs hints
    d.rectangle([40, 160, 58, 200], fill=(40, 28, 24, 255))
    d.rectangle([340, 170, 358, 210], fill=(40, 28, 24, 255))
    return speckle(im, 0.05, (8, 8, 12, 255), 8)


def draw_cove(open_curtain: bool) -> Image.Image:
    im = room_base()
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 399, 249], fill=(8, 6, 12, 255))
    # wooden side walls
    d.polygon([(0, 0), (70, 30), (70, 230), (0, 249)], fill=(42, 28, 24, 255))
    d.polygon([(399, 0), (330, 30), (330, 230), (399, 249)], fill=(42, 28, 24, 255))
    d.rectangle([0, 200, 399, 249], fill=(28, 20, 18, 255))
    if open_curtain:
        d.rectangle([150, 20, 250, 200], fill=(4, 4, 8, 255))
        for x in range(80, 150, 8):
            d.rectangle([x, 16, x + 6, 206], fill=CURTAIN if (x // 8) % 2 == 0 else CURTAIN_D)
        for x in range(250, 320, 8):
            d.rectangle([x, 16, x + 6, 206], fill=CURTAIN if (x // 8) % 2 == 0 else CURTAIN_D)
        d.text((168, 90), "?", font=font(20), fill=(80, 20, 30, 255))
    else:
        for x in range(90, 310, 10):
            c = CURTAIN if (x // 10) % 2 == 0 else CURTAIN_D
            # slight wave
            shift = int(6 * math.sin(x * 0.08))
            d.rectangle([x, 16 + shift, x + 8, 210], fill=c)
        d.rectangle([90, 12, 310, 28], fill=(40, 20, 28, 255))
        # gold stars
        for sx in (120, 180, 240, 280):
            d.polygon([(sx, 40), (sx + 4, 48), (sx + 12, 48), (sx + 6, 54), (sx + 8, 64), (sx, 58), (sx - 8, 64), (sx - 6, 54), (sx - 12, 48), (sx - 4, 48)], fill=YEL)
    d.text((118, 220), "CURTAIN COVE", font=font(8), fill=(180, 160, 120, 255))
    return im


def draw_hall_cam(east: bool, corner: bool) -> Image.Image:
    im = new(400, 250, (8, 8, 12, 255))
    d = ImageDraw.Draw(im)
    # one-point perspective hallway
    vx, vy = (320, 120) if not east else (80, 120)
    if corner:
        vx = 200
        vy = 100
    wall_l = (28, 22, 40, 255) if not east else (36, 24, 32, 255)
    wall_r = (18, 16, 28, 255)
    d.polygon([(0, 0), (vx, vy), (vx, vy + 20), (0, 200)], fill=wall_l)
    d.polygon([(399, 0), (vx, vy), (vx, vy + 20), (399, 200)], fill=wall_r if not east else wall_l)
    # ceiling
    d.polygon([(0, 0), (399, 0), (vx + 10, vy), (vx - 10, vy)], fill=(12, 12, 18, 255))
    # floor
    d.polygon([(0, 200), (399, 200), (vx + 8, vy + 18), (vx - 8, vy + 18)], fill=(16, 12, 16, 255))
    # floor checkers in perspective
    for i in range(8):
        t0 = i / 8
        t1 = (i + 1) / 8
        z0 = t0 ** 1.4
        z1 = t1 ** 1.4
        y0 = 248 - (248 - (vy + 18)) * (1 - z0) - 48 * (1 - z0)
        # simpler rows
        yy0 = int(vy + 20 + (220 - vy) * (i / 8) ** 1.2)
        yy1 = int(vy + 20 + (220 - vy) * ((i + 1) / 8) ** 1.2)
        span0 = 20 + i * 28
        span1 = 20 + (i + 1) * 28
        for c in range(6):
            if (c + i) % 2:
                continue
            u0 = (c / 6 - 0.5)
            u1 = ((c + 1) / 6 - 0.5)
            poly = [
                (vx + u0 * span0, yy0),
                (vx + u1 * span0, yy0),
                (vx + u1 * span1, yy1),
                (vx + u0 * span1, yy1),
            ]
            d.polygon(poly, fill=CHK_R if east else (150, 28, 36, 255))
    # ceiling lamps receding
    for i, lamp in enumerate((0.25, 0.45, 0.65)):
        lx = int(vx * lamp + (200) * (1 - lamp))
        ly = int(20 + lamp * 40)
        if east:
            lx = int(80 * lamp + 300 * (1 - lamp))
        d.rectangle([lx, ly, lx + 18, ly + 6], fill=(230, 220, 180, 255))
    # posters
    if not corner:
        px = 30 if not east else 300
        d.rectangle([px, 70, px + 46, 120], fill=(200, 190, 170, 255), outline=OUTL)
        d.rectangle([px + 4, 74, px + 42, 92], fill=RED)
        d.text((px + 8, 78), "BOXY", font=font(7), fill=CHK_W)
    else:
        # close door at end — the office door
        d.rectangle([160, 70, 250, 200], fill=(6, 6, 10, 255), outline=METAL, width=3)
        d.text((168, 40), "OFFICE", font=font(8), fill=(160, 150, 140, 255))
    # different prop so east != west
    if east and not corner:
        d.rectangle([40, 150, 70, 200], fill=(60, 40, 30, 255))  # trash
        d.ellipse([48, 142, 64, 156], fill=(40, 30, 24, 255))
    if not east and not corner:
        d.polygon([(340, 200), (360, 90), (372, 200)], fill=(30, 40, 36, 255))  # plant
        ell(d, 356, 96, 16, 10, (40, 80, 48, 255), None, 0)
    return speckle(im, 0.06, (0, 0, 0, 255), 12 + int(east) + int(corner) * 3)


def draw_kitchen() -> Image.Image:
    im = new(400, 250, (6, 6, 8, 255))
    d = ImageDraw.Draw(im)
    # very dim but readable kitchen
    d.rectangle([0, 0, 399, 160], fill=(16, 18, 22, 255))
    d.rectangle([0, 160, 399, 249], fill=(20, 20, 22, 255))
    # tiles
    for y in range(20, 150, 16):
        for x in range(10, 390, 16):
            d.rectangle([x, y, x + 14, y + 14], outline=(28, 30, 36, 255))
    # counters
    d.rectangle([0, 140, 399, 175], fill=(40, 42, 48, 255))
    d.rectangle([0, 175, 399, 210], fill=(24, 26, 30, 255))
    # stove with faint glow
    d.rectangle([250, 100, 330, 150], fill=(18, 18, 20, 255), outline=METAL)
    d.ellipse([268, 112, 312, 142], fill=(90, 30, 16, 255))
    d.ellipse([280, 120, 300, 134], fill=(180, 80, 30, 180))
    # hanging pots
    for x in (60, 110, 160):
        d.line([(x, 20), (x, 48)], fill=METAL_L, width=2)
        ell(d, x, 64, 16, 12, METAL, OUTL, 2)
    # sink
    d.ellipse([40, 148, 100, 168], fill=(16, 20, 24, 255), outline=METAL_L)
    d.text((118, 220), "KITCHEN", font=font(8), fill=(90, 90, 100, 255))
    return speckle(im, 0.08, (0, 0, 0, 255), 19)


def draw_parts() -> Image.Image:
    im = new(400, 250, (12, 12, 14, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 399, 249], fill=(18, 16, 20, 255))
    # shelves
    for y in (30, 100, 170):
        d.rectangle([16, y, 384, y + 8], fill=METAL_D, outline=METAL)
    # spare heads
    for i, x in enumerate((50, 120, 190)):
        ell(d, x, 72, 22, 20, FUR if i != 2 else PURP, OUTL, 2)
        ell(d, x - 8, 70, 5, 6, EYE, None, 0)
        ell(d, x + 8, 70, 5, 6, EYE, None, 0)
        if i == 0:
            rect(d, x - 10, 48, 20, 10, HAT, None, 0)
    # endo arm
    d.rectangle([250, 48, 270, 90], fill=METAL)
    ell(d, 260, 96, 12, 12, METAL_L, OUTL, 2)
    d.rectangle([300, 120, 360, 136], fill=METAL_D)
    d.rectangle([40, 130, 160, 160], fill=WOOD_D, outline=WOOD)
    # wires
    d.line([(20, 180), (80, 210), (140, 190), (220, 230)], fill=(140, 30, 30, 255), width=2)
    d.line([(230, 200), (300, 230), (370, 200)], fill=(30, 30, 140, 255), width=2)
    # bulb
    ell(d, 330, 48, 10, 14, (240, 220, 140, 255), None, 0)
    d.polygon([(300, 20), (360, 20), (350, 80), (310, 80)], fill=(255, 230, 160, 30))
    d.text((130, 214), "PARTS ROOM", font=font(8), fill=(170, 160, 150, 255))
    return speckle(im, 0.05, (0, 0, 0, 255), 23)


def fit_body(src: Image.Image, height: int) -> Image.Image:
    w = max(1, int(src.width * (height / src.height)))
    return src.resize((w, height), Image.Resampling.NEAREST)


def crop_alpha(im: Image.Image, pad: int = 2) -> Image.Image:
    arr = np.array(im)
    ys, xs = np.where(arr[:, :, 3] > 16)
    if len(xs) == 0:
        return im
    x0 = max(0, int(xs.min()) - pad)
    x1 = min(im.width, int(xs.max()) + pad + 1)
    y0 = max(0, int(ys.min()) - pad)
    y1 = min(im.height, int(ys.max()) + pad + 1)
    return im.crop((x0, y0, x1, y1))


def pixelate(im: Image.Image, factor: int = 2) -> Image.Image:
    w, h = im.size
    sw, sh = max(1, w // factor), max(1, h // factor)
    small = im.resize((sw, sh), Image.Resampling.BOX)
    return small.resize((sw * factor, sh * factor), Image.Resampling.NEAREST)


def save(im: Image.Image, name: str, factor: int = 2, crop: bool = False):
    if crop:
        im = crop_alpha(im)
    im = pixelate(im, factor)
    path = os.path.join(OUT, name)
    im.save(path, "PNG")
    print(name, im.size)


def main():
    save(draw_office(), "office.png")
    save(draw_door(), "door.png")
    save(draw_hall(False), "hall_l.png")
    save(draw_hall(True), "hall_r.png")
    for i in range(4):
        save(draw_fan(i), f"fan{i}.png")
    save(draw_pizza(), "pizza.png")
    save(draw_stage(), "cam_1a.png")
    save(draw_dining(), "cam_1b.png")
    save(draw_cove(False), "cam_1c.png")
    save(draw_cove(True), "cam_1c_open.png")
    save(draw_hall_cam(False, False), "cam_2a.png")
    save(draw_hall_cam(False, True), "cam_2b.png")
    save(draw_hall_cam(True, False), "cam_3a.png")
    save(draw_hall_cam(True, True), "cam_3b.png")
    save(draw_kitchen(), "cam_4a.png")
    save(draw_parts(), "cam_4b.png")

    # portraits / scares — detailed busts
    for scare in range(4):
        save(draw_boxy(scare), f"scare_boxy_{scare}.png", crop=True)
        save(draw_pepper(scare), f"scare_pepper_{scare}.png", crop=True)
        save(draw_crumb(scare), f"scare_crumb_{scare}.png", crop=True)
        save(draw_mozz(scare), f"scare_mozz_{scare}.png", crop=True)
    save(draw_boxy(0, thumb=True), "boxy_win.png", crop=True)
    save(draw_mozz_peek(), "mozz_peek.png", crop=True)

    # camera-scale bodies (nearest-neighbor downscale of the calm portrait crop)
    for who, fn in (
        ("boxy", lambda: draw_boxy(0)),
        ("pepper", lambda: draw_pepper(0)),
        ("crumb", lambda: draw_crumb(0)),
        ("mozz", lambda: draw_mozz(0)),
    ):
        body = fit_body(crop_alpha(fn()), 200)
        save(body, f"spr_{who}.png", factor=2)
        save(fit_body(crop_alpha(fn()), 170), f"door_{who}.png", factor=2)

    # menu portrait a bit larger already scare_boxy_0
    print("assets written", OUT)


if __name__ == "__main__":
    main()
